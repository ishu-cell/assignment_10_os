vttest.o: vttest.c /usr/include/stdc-predef.h types.h user.h
