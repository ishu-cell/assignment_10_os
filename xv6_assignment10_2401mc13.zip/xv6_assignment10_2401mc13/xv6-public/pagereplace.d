pagereplace.o: pagereplace.c /usr/include/stdc-predef.h types.h user.h
