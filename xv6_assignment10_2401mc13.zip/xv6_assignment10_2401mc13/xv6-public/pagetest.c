#include "types.h"
#include "user.h"

#define PGSIZE 4096

int
main(void)
{
  volatile char *page;
  int pid;

  printf(1, "Assignment 10 - Q3: page information and read-only protection\n");

  page = (volatile char*)sbrk(PGSIZE);
  if(page == (char*)-1){
    printf(1, "pagetest: sbrk failed\n");
    exit();
  }

  // First write causes a lazy page allocation in this cumulative xv6 tree.
  page[0] = 'A';
  printf(1, "\nBefore removing write permission:\n");
  if(pageinfo((int)page) < 0){
    printf(1, "pagetest: page is unexpectedly unmapped\n");
    exit();
  }

  if(setreadonly((int)page) < 0){
    printf(1, "pagetest: setreadonly failed\n");
    exit();
  }

  printf(1, "\nAfter removing write permission:\n");
  pageinfo((int)page);

  // Test the protection fault in a child so the parent can survive it.
  pid = fork();
  if(pid < 0){
    printf(1, "pagetest: fork failed\n");
    exit();
  }
  if(pid == 0){
    printf(1, "Child: attempting to write to the read-only page...\n");
    page[0] = 'B';
    printf(1, "ERROR: protected write unexpectedly succeeded\n");
    exit();
  }

  wait();
  printf(1, "Parent: survived; child should have been terminated by the protection fault.\n");
  exit();
}
