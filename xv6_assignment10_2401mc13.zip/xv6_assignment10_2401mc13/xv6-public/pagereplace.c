#include "types.h"
#include "user.h"

#define MAXF 10
#define MAXREF 100
#define LINELEN 512

static int
parse_refs(char *line, int refs[])
{
  int n = 0;
  char *p = line;

  while(*p){
    int value = 0;
    while(*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n')
      p++;
    if(*p == 0)
      break;
    if(*p < '0' || *p > '9')
      return -1;
    while(*p >= '0' && *p <= '9'){
      value = value * 10 + (*p - '0');
      p++;
    }
    if(n >= MAXREF)
      return -1;
    refs[n++] = value;
    if(*p && *p != ' ' && *p != '\t' && *p != '\r' && *p != '\n')
      return -1;
  }
  return n;
}

static int
find_page(int frames[], int nf, int page)
{
  int i;
  for(i = 0; i < nf; i++)
    if(frames[i] == page)
      return i;
  return -1;
}

static void
print_frames(int frames[], int nf)
{
  int i;
  printf(1, "[");
  for(i = 0; i < nf; i++){
    if(i)
      printf(1, " ");
    if(frames[i] < 0)
      printf(1, "-");
    else
      printf(1, "%d", frames[i]);
  }
  printf(1, "]");
}

static int
run_fifo(int refs[], int n, int nf, int trace, int *hits_out)
{
  int frames[MAXF];
  int i, j, next = 0, faults = 0, hits = 0;

  for(i = 0; i < nf; i++)
    frames[i] = -1;
  if(trace)
    printf(1, "\n--- FIFO with %d frame(s) ---\n", nf);

  for(i = 0; i < n; i++){
    j = find_page(frames, nf, refs[i]);
    if(j >= 0){
      hits++;
      if(trace){
        printf(1, "ref %d: HIT   ", refs[i]);
        print_frames(frames, nf);
        printf(1, "\n");
      }
    } else {
      faults++;
      frames[next] = refs[i];
      next = (next + 1) % nf;
      if(trace){
        printf(1, "ref %d: FAULT ", refs[i]);
        print_frames(frames, nf);
        printf(1, "\n");
      }
    }
  }
  if(trace)
    printf(1, "FIFO: faults=%d hits=%d\n", faults, hits);
  *hits_out = hits;
  return faults;
}

static int
run_lru(int refs[], int n, int nf, int trace, int *hits_out)
{
  int frames[MAXF], last[MAXF];
  int i, j, k, victim, oldest, faults = 0, hits = 0;

  for(i = 0; i < nf; i++){
    frames[i] = -1;
    last[i] = -1;
  }
  if(trace)
    printf(1, "\n--- LRU with %d frame(s) ---\n", nf);

  for(i = 0; i < n; i++){
    j = find_page(frames, nf, refs[i]);
    if(j >= 0){
      hits++;
      last[j] = i;
      if(trace){
        printf(1, "ref %d: HIT   ", refs[i]);
        print_frames(frames, nf);
        printf(1, "\n");
      }
    } else {
      faults++;
      victim = -1;
      for(k = 0; k < nf; k++)
        if(frames[k] < 0){ victim = k; break; }
      if(victim < 0){
        victim = 0;
        oldest = last[0];
        for(k = 1; k < nf; k++)
          if(last[k] < oldest){ oldest = last[k]; victim = k; }
      }
      frames[victim] = refs[i];
      last[victim] = i;
      if(trace){
        printf(1, "ref %d: FAULT ", refs[i]);
        print_frames(frames, nf);
        printf(1, "\n");
      }
    }
  }
  if(trace)
    printf(1, "LRU: faults=%d hits=%d\n", faults, hits);
  *hits_out = hits;
  return faults;
}

static int
next_use(int refs[], int n, int page, int from)
{
  int i;
  for(i = from; i < n; i++)
    if(refs[i] == page)
      return i;
  return n + 1; // not referenced again: optimal victim
}

static int
run_opt(int refs[], int n, int nf, int trace, int *hits_out)
{
  int frames[MAXF];
  int i, j, k, victim, farthest, when, faults = 0, hits = 0;

  for(i = 0; i < nf; i++)
    frames[i] = -1;
  if(trace)
    printf(1, "\n--- Optimal with %d frame(s) ---\n", nf);

  for(i = 0; i < n; i++){
    j = find_page(frames, nf, refs[i]);
    if(j >= 0){
      hits++;
      if(trace){
        printf(1, "ref %d: HIT   ", refs[i]);
        print_frames(frames, nf);
        printf(1, "\n");
      }
    } else {
      faults++;
      victim = -1;
      for(k = 0; k < nf; k++)
        if(frames[k] < 0){ victim = k; break; }
      if(victim < 0){
        victim = 0;
        farthest = next_use(refs, n, frames[0], i + 1);
        for(k = 1; k < nf; k++){
          when = next_use(refs, n, frames[k], i + 1);
          if(when > farthest){ farthest = when; victim = k; }
        }
      }
      frames[victim] = refs[i];
      if(trace){
        printf(1, "ref %d: FAULT ", refs[i]);
        print_frames(frames, nf);
        printf(1, "\n");
      }
    }
  }
  if(trace)
    printf(1, "Optimal: faults=%d hits=%d\n", faults, hits);
  *hits_out = hits;
  return faults;
}

int
main(void)
{
  char line[LINELEN];
  int refs[MAXREF];
  int n, nf, hits;
  int h3, h4, h5;
  int ff, fl, fo;

  printf(1, "Assignment 10 - Q4: FIFO, LRU and Optimal page replacement\n");
  printf(1, "Enter frame count for detailed trace (1-%d): ", MAXF);
  if(gets(line, sizeof(line)) == 0){
    printf(1, "No frame count received.\n");
    exit();
  }
  nf = atoi(line);
  if(nf < 1 || nf > MAXF){
    printf(1, "Invalid frame count. Use 1 through %d.\n", MAXF);
    exit();
  }

  printf(1, "Enter space-separated page reference string:\n");
  if(gets(line, sizeof(line)) == 0){
    printf(1, "No reference string received.\n");
    exit();
  }
  n = parse_refs(line, refs);
  if(n <= 0){
    printf(1, "Invalid reference string (maximum %d references).\n", MAXREF);
    exit();
  }
  printf(1, "References=%d, detailed trace frames=%d\n", n, nf);

  run_fifo(refs, n, nf, 1, &hits);
  run_lru(refs, n, nf, 1, &hits);
  run_opt(refs, n, nf, 1, &hits);

  printf(1, "\n--- Comparison for 3, 4 and 5 frames ---\n");
  printf(1, "Frames Alg      Faults Hits HitRatio FaultRatio\n");
  for(nf = 3; nf <= 5; nf++){
    ff = run_fifo(refs, n, nf, 0, &h3);
    fl = run_lru(refs, n, nf, 0, &h4);
    fo = run_opt(refs, n, nf, 0, &h5);
    printf(1, "%d      FIFO     %d      %d    %d%%      %d%%\n",
           nf, ff, h3, h3 * 100 / n, ff * 100 / n);
    printf(1, "%d      LRU      %d      %d    %d%%      %d%%\n",
           nf, fl, h4, h4 * 100 / n, fl * 100 / n);
    printf(1, "%d      Optimal  %d      %d    %d%%      %d%%\n",
           nf, fo, h5, h5 * 100 / n, fo * 100 / n);
  }
  printf(1, "Optimal gives the minimum possible faults for this known string.\n");
  exit();
}
