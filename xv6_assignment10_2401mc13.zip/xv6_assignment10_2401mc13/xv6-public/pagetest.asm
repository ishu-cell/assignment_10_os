
_pagetest:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:

#define PGSIZE 4096

int
main(void)
{
   0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
   4:	83 e4 f0             	and    $0xfffffff0,%esp
   7:	ff 71 fc             	push   -0x4(%ecx)
   a:	55                   	push   %ebp
   b:	89 e5                	mov    %esp,%ebp
   d:	53                   	push   %ebx
   e:	51                   	push   %ecx
  volatile char *page;
  int pid;

  printf(1, "Assignment 10 - Q3: page information and read-only protection\n");
   f:	83 ec 08             	sub    $0x8,%esp
  12:	68 a8 08 00 00       	push   $0x8a8
  17:	6a 01                	push   $0x1
  19:	e8 22 05 00 00       	call   540 <printf>

  page = (volatile char*)sbrk(PGSIZE);
  1e:	c7 04 24 00 10 00 00 	movl   $0x1000,(%esp)
  25:	e8 f1 03 00 00       	call   41b <sbrk>
  if(page == (char*)-1){
  2a:	83 c4 10             	add    $0x10,%esp
  2d:	83 f8 ff             	cmp    $0xffffffff,%eax
  30:	0f 84 92 00 00 00    	je     c8 <main+0xc8>
    exit();
  }

  // First write causes a lazy page allocation in this cumulative xv6 tree.
  page[0] = 'A';
  printf(1, "\nBefore removing write permission:\n");
  36:	83 ec 08             	sub    $0x8,%esp
  page[0] = 'A';
  39:	c6 00 41             	movb   $0x41,(%eax)
  3c:	89 c3                	mov    %eax,%ebx
  printf(1, "\nBefore removing write permission:\n");
  3e:	68 e8 08 00 00       	push   $0x8e8
  43:	6a 01                	push   $0x1
  45:	e8 f6 04 00 00       	call   540 <printf>
  if(pageinfo((int)page) < 0){
  4a:	89 1c 24             	mov    %ebx,(%esp)
  4d:	e8 01 04 00 00       	call   453 <pageinfo>
  52:	83 c4 10             	add    $0x10,%esp
  55:	85 c0                	test   %eax,%eax
  57:	78 5c                	js     b5 <main+0xb5>
    printf(1, "pagetest: page is unexpectedly unmapped\n");
    exit();
  }

  if(setreadonly((int)page) < 0){
  59:	83 ec 0c             	sub    $0xc,%esp
  5c:	53                   	push   %ebx
  5d:	e8 f9 03 00 00       	call   45b <setreadonly>
  62:	83 c4 10             	add    $0x10,%esp
  65:	85 c0                	test   %eax,%eax
  67:	0f 88 81 00 00 00    	js     ee <main+0xee>
    printf(1, "pagetest: setreadonly failed\n");
    exit();
  }

  printf(1, "\nAfter removing write permission:\n");
  6d:	50                   	push   %eax
  6e:	50                   	push   %eax
  6f:	68 38 09 00 00       	push   $0x938
  74:	6a 01                	push   $0x1
  76:	e8 c5 04 00 00       	call   540 <printf>
  pageinfo((int)page);
  7b:	89 1c 24             	mov    %ebx,(%esp)
  7e:	e8 d0 03 00 00       	call   453 <pageinfo>

  // Test the protection fault in a child so the parent can survive it.
  pid = fork();
  83:	e8 03 03 00 00       	call   38b <fork>
  if(pid < 0){
  88:	83 c4 10             	add    $0x10,%esp
  8b:	85 c0                	test   %eax,%eax
  8d:	78 4c                	js     db <main+0xdb>
    printf(1, "pagetest: fork failed\n");
    exit();
  }
  if(pid == 0){
  8f:	75 70                	jne    101 <main+0x101>
    printf(1, "Child: attempting to write to the read-only page...\n");
  91:	52                   	push   %edx
  92:	52                   	push   %edx
  93:	68 5c 09 00 00       	push   $0x95c
  98:	6a 01                	push   $0x1
  9a:	e8 a1 04 00 00       	call   540 <printf>
    page[0] = 'B';
  9f:	c6 03 42             	movb   $0x42,(%ebx)
    printf(1, "ERROR: protected write unexpectedly succeeded\n");
  a2:	59                   	pop    %ecx
  a3:	5b                   	pop    %ebx
  a4:	68 94 09 00 00       	push   $0x994
  a9:	6a 01                	push   $0x1
  ab:	e8 90 04 00 00       	call   540 <printf>
    exit();
  b0:	e8 de 02 00 00       	call   393 <exit>
    printf(1, "pagetest: page is unexpectedly unmapped\n");
  b5:	50                   	push   %eax
  b6:	50                   	push   %eax
  b7:	68 0c 09 00 00       	push   $0x90c
  bc:	6a 01                	push   $0x1
  be:	e8 7d 04 00 00       	call   540 <printf>
    exit();
  c3:	e8 cb 02 00 00       	call   393 <exit>
    printf(1, "pagetest: sbrk failed\n");
  c8:	50                   	push   %eax
  c9:	50                   	push   %eax
  ca:	68 12 0a 00 00       	push   $0xa12
  cf:	6a 01                	push   $0x1
  d1:	e8 6a 04 00 00       	call   540 <printf>
    exit();
  d6:	e8 b8 02 00 00       	call   393 <exit>
    printf(1, "pagetest: fork failed\n");
  db:	50                   	push   %eax
  dc:	50                   	push   %eax
  dd:	68 47 0a 00 00       	push   $0xa47
  e2:	6a 01                	push   $0x1
  e4:	e8 57 04 00 00       	call   540 <printf>
    exit();
  e9:	e8 a5 02 00 00       	call   393 <exit>
    printf(1, "pagetest: setreadonly failed\n");
  ee:	50                   	push   %eax
  ef:	50                   	push   %eax
  f0:	68 29 0a 00 00       	push   $0xa29
  f5:	6a 01                	push   $0x1
  f7:	e8 44 04 00 00       	call   540 <printf>
    exit();
  fc:	e8 92 02 00 00       	call   393 <exit>
  }

  wait();
 101:	e8 95 02 00 00       	call   39b <wait>
  printf(1, "Parent: survived; child should have been terminated by the protection fault.\n");
 106:	50                   	push   %eax
 107:	50                   	push   %eax
 108:	68 c4 09 00 00       	push   $0x9c4
 10d:	6a 01                	push   $0x1
 10f:	e8 2c 04 00 00       	call   540 <printf>
  exit();
 114:	e8 7a 02 00 00       	call   393 <exit>
 119:	66 90                	xchg   %ax,%ax
 11b:	66 90                	xchg   %ax,%ax
 11d:	66 90                	xchg   %ax,%ax
 11f:	90                   	nop

00000120 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
 120:	55                   	push   %ebp
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 121:	31 c0                	xor    %eax,%eax
{
 123:	89 e5                	mov    %esp,%ebp
 125:	53                   	push   %ebx
 126:	8b 4d 08             	mov    0x8(%ebp),%ecx
 129:	8b 5d 0c             	mov    0xc(%ebp),%ebx
 12c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  while((*s++ = *t++) != 0)
 130:	0f b6 14 03          	movzbl (%ebx,%eax,1),%edx
 134:	88 14 01             	mov    %dl,(%ecx,%eax,1)
 137:	83 c0 01             	add    $0x1,%eax
 13a:	84 d2                	test   %dl,%dl
 13c:	75 f2                	jne    130 <strcpy+0x10>
    ;
  return os;
}
 13e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 141:	89 c8                	mov    %ecx,%eax
 143:	c9                   	leave
 144:	c3                   	ret
 145:	8d 76 00             	lea    0x0(%esi),%esi
 148:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 14f:	00 

00000150 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 150:	55                   	push   %ebp
 151:	89 e5                	mov    %esp,%ebp
 153:	53                   	push   %ebx
 154:	8b 55 08             	mov    0x8(%ebp),%edx
 157:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(*p && *p == *q)
 15a:	0f b6 02             	movzbl (%edx),%eax
 15d:	84 c0                	test   %al,%al
 15f:	75 2d                	jne    18e <strcmp+0x3e>
 161:	eb 4a                	jmp    1ad <strcmp+0x5d>
 163:	eb 1b                	jmp    180 <strcmp+0x30>
 165:	8d 76 00             	lea    0x0(%esi),%esi
 168:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 16f:	00 
 170:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 177:	00 
 178:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 17f:	00 
 180:	0f b6 42 01          	movzbl 0x1(%edx),%eax
    p++, q++;
 184:	83 c2 01             	add    $0x1,%edx
  while(*p && *p == *q)
 187:	84 c0                	test   %al,%al
 189:	74 15                	je     1a0 <strcmp+0x50>
 18b:	83 c1 01             	add    $0x1,%ecx
 18e:	0f b6 19             	movzbl (%ecx),%ebx
 191:	38 c3                	cmp    %al,%bl
 193:	74 eb                	je     180 <strcmp+0x30>
  return (uchar)*p - (uchar)*q;
 195:	29 d8                	sub    %ebx,%eax
}
 197:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 19a:	c9                   	leave
 19b:	c3                   	ret
 19c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  return (uchar)*p - (uchar)*q;
 1a0:	0f b6 59 01          	movzbl 0x1(%ecx),%ebx
 1a4:	31 c0                	xor    %eax,%eax
 1a6:	29 d8                	sub    %ebx,%eax
}
 1a8:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 1ab:	c9                   	leave
 1ac:	c3                   	ret
  return (uchar)*p - (uchar)*q;
 1ad:	0f b6 19             	movzbl (%ecx),%ebx
 1b0:	31 c0                	xor    %eax,%eax
 1b2:	eb e1                	jmp    195 <strcmp+0x45>
 1b4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 1b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 1bf:	00 

000001c0 <strlen>:

uint
strlen(const char *s)
{
 1c0:	55                   	push   %ebp
 1c1:	89 e5                	mov    %esp,%ebp
 1c3:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  for(n = 0; s[n]; n++)
 1c6:	80 3a 00             	cmpb   $0x0,(%edx)
 1c9:	74 15                	je     1e0 <strlen+0x20>
 1cb:	31 c0                	xor    %eax,%eax
 1cd:	8d 76 00             	lea    0x0(%esi),%esi
 1d0:	83 c0 01             	add    $0x1,%eax
 1d3:	89 c1                	mov    %eax,%ecx
 1d5:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
 1d9:	75 f5                	jne    1d0 <strlen+0x10>
    ;
  return n;
}
 1db:	89 c8                	mov    %ecx,%eax
 1dd:	5d                   	pop    %ebp
 1de:	c3                   	ret
 1df:	90                   	nop
  for(n = 0; s[n]; n++)
 1e0:	31 c9                	xor    %ecx,%ecx
}
 1e2:	5d                   	pop    %ebp
 1e3:	89 c8                	mov    %ecx,%eax
 1e5:	c3                   	ret
 1e6:	66 90                	xchg   %ax,%ax
 1e8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 1ef:	00 

000001f0 <memset>:

void*
memset(void *dst, int c, uint n)
{
 1f0:	55                   	push   %ebp
 1f1:	89 e5                	mov    %esp,%ebp
 1f3:	57                   	push   %edi
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
 1f4:	8b 4d 10             	mov    0x10(%ebp),%ecx
 1f7:	8b 45 0c             	mov    0xc(%ebp),%eax
 1fa:	8b 7d 08             	mov    0x8(%ebp),%edi
 1fd:	fc                   	cld
 1fe:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
 200:	8b 45 08             	mov    0x8(%ebp),%eax
 203:	8b 7d fc             	mov    -0x4(%ebp),%edi
 206:	c9                   	leave
 207:	c3                   	ret
 208:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 20f:	00 

00000210 <strchr>:

char*
strchr(const char *s, char c)
{
 210:	55                   	push   %ebp
 211:	89 e5                	mov    %esp,%ebp
 213:	8b 45 08             	mov    0x8(%ebp),%eax
 216:	0f b6 4d 0c          	movzbl 0xc(%ebp),%ecx
  for(; *s; s++)
 21a:	0f b6 10             	movzbl (%eax),%edx
 21d:	84 d2                	test   %dl,%dl
 21f:	75 1a                	jne    23b <strchr+0x2b>
 221:	eb 25                	jmp    248 <strchr+0x38>
 223:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
 228:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 22f:	00 
 230:	0f b6 50 01          	movzbl 0x1(%eax),%edx
 234:	83 c0 01             	add    $0x1,%eax
 237:	84 d2                	test   %dl,%dl
 239:	74 0d                	je     248 <strchr+0x38>
    if(*s == c)
 23b:	38 d1                	cmp    %dl,%cl
 23d:	75 f1                	jne    230 <strchr+0x20>
      return (char*)s;
  return 0;
}
 23f:	5d                   	pop    %ebp
 240:	c3                   	ret
 241:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  return 0;
 248:	31 c0                	xor    %eax,%eax
}
 24a:	5d                   	pop    %ebp
 24b:	c3                   	ret
 24c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000250 <gets>:

char*
gets(char *buf, int max)
{
 250:	55                   	push   %ebp
 251:	89 e5                	mov    %esp,%ebp
 253:	57                   	push   %edi
 254:	56                   	push   %esi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    cc = read(0, &c, 1);
 255:	8d 7d e7             	lea    -0x19(%ebp),%edi
{
 258:	53                   	push   %ebx
  for(i=0; i+1 < max; ){
 259:	31 db                	xor    %ebx,%ebx
{
 25b:	83 ec 1c             	sub    $0x1c,%esp
  for(i=0; i+1 < max; ){
 25e:	eb 27                	jmp    287 <gets+0x37>
    cc = read(0, &c, 1);
 260:	83 ec 04             	sub    $0x4,%esp
 263:	6a 01                	push   $0x1
 265:	57                   	push   %edi
 266:	6a 00                	push   $0x0
 268:	e8 3e 01 00 00       	call   3ab <read>
    if(cc < 1)
 26d:	83 c4 10             	add    $0x10,%esp
 270:	85 c0                	test   %eax,%eax
 272:	7e 1d                	jle    291 <gets+0x41>
      break;
    buf[i++] = c;
 274:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
 278:	8b 55 08             	mov    0x8(%ebp),%edx
 27b:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
    if(c == '\n' || c == '\r')
 27f:	3c 0a                	cmp    $0xa,%al
 281:	74 1d                	je     2a0 <gets+0x50>
 283:	3c 0d                	cmp    $0xd,%al
 285:	74 19                	je     2a0 <gets+0x50>
  for(i=0; i+1 < max; ){
 287:	89 de                	mov    %ebx,%esi
 289:	83 c3 01             	add    $0x1,%ebx
 28c:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
 28f:	7c cf                	jl     260 <gets+0x10>
      break;
  }
  buf[i] = '\0';
 291:	8b 45 08             	mov    0x8(%ebp),%eax
 294:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
 298:	8d 65 f4             	lea    -0xc(%ebp),%esp
 29b:	5b                   	pop    %ebx
 29c:	5e                   	pop    %esi
 29d:	5f                   	pop    %edi
 29e:	5d                   	pop    %ebp
 29f:	c3                   	ret
  buf[i] = '\0';
 2a0:	8b 45 08             	mov    0x8(%ebp),%eax
    buf[i++] = c;
 2a3:	89 de                	mov    %ebx,%esi
  buf[i] = '\0';
 2a5:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
}
 2a9:	8d 65 f4             	lea    -0xc(%ebp),%esp
 2ac:	5b                   	pop    %ebx
 2ad:	5e                   	pop    %esi
 2ae:	5f                   	pop    %edi
 2af:	5d                   	pop    %ebp
 2b0:	c3                   	ret
 2b1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 2b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 2bf:	00 

000002c0 <stat>:

int
stat(const char *n, struct stat *st)
{
 2c0:	55                   	push   %ebp
 2c1:	89 e5                	mov    %esp,%ebp
 2c3:	56                   	push   %esi
 2c4:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 2c5:	83 ec 08             	sub    $0x8,%esp
 2c8:	6a 00                	push   $0x0
 2ca:	ff 75 08             	push   0x8(%ebp)
 2cd:	e8 01 01 00 00       	call   3d3 <open>
  if(fd < 0)
 2d2:	83 c4 10             	add    $0x10,%esp
 2d5:	85 c0                	test   %eax,%eax
 2d7:	78 27                	js     300 <stat+0x40>
    return -1;
  r = fstat(fd, st);
 2d9:	83 ec 08             	sub    $0x8,%esp
 2dc:	ff 75 0c             	push   0xc(%ebp)
 2df:	89 c3                	mov    %eax,%ebx
 2e1:	50                   	push   %eax
 2e2:	e8 04 01 00 00       	call   3eb <fstat>
  close(fd);
 2e7:	89 1c 24             	mov    %ebx,(%esp)
  r = fstat(fd, st);
 2ea:	89 c6                	mov    %eax,%esi
  close(fd);
 2ec:	e8 ca 00 00 00       	call   3bb <close>
  return r;
 2f1:	83 c4 10             	add    $0x10,%esp
}
 2f4:	8d 65 f8             	lea    -0x8(%ebp),%esp
 2f7:	89 f0                	mov    %esi,%eax
 2f9:	5b                   	pop    %ebx
 2fa:	5e                   	pop    %esi
 2fb:	5d                   	pop    %ebp
 2fc:	c3                   	ret
 2fd:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
 300:	be ff ff ff ff       	mov    $0xffffffff,%esi
 305:	eb ed                	jmp    2f4 <stat+0x34>
 307:	90                   	nop
 308:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 30f:	00 

00000310 <atoi>:

int
atoi(const char *s)
{
 310:	55                   	push   %ebp
 311:	89 e5                	mov    %esp,%ebp
 313:	53                   	push   %ebx
 314:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 317:	0f be 02             	movsbl (%edx),%eax
 31a:	8d 48 d0             	lea    -0x30(%eax),%ecx
 31d:	80 f9 09             	cmp    $0x9,%cl
  n = 0;
 320:	b9 00 00 00 00       	mov    $0x0,%ecx
  while('0' <= *s && *s <= '9')
 325:	77 2e                	ja     355 <atoi+0x45>
 327:	eb 17                	jmp    340 <atoi+0x30>
 329:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 330:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 337:	00 
 338:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 33f:	00 
    n = n*10 + *s++ - '0';
 340:	83 c2 01             	add    $0x1,%edx
 343:	8d 0c 89             	lea    (%ecx,%ecx,4),%ecx
 346:	8d 4c 48 d0          	lea    -0x30(%eax,%ecx,2),%ecx
  while('0' <= *s && *s <= '9')
 34a:	0f be 02             	movsbl (%edx),%eax
 34d:	8d 58 d0             	lea    -0x30(%eax),%ebx
 350:	80 fb 09             	cmp    $0x9,%bl
 353:	76 eb                	jbe    340 <atoi+0x30>
  return n;
}
 355:	8b 5d fc             	mov    -0x4(%ebp),%ebx
 358:	89 c8                	mov    %ecx,%eax
 35a:	c9                   	leave
 35b:	c3                   	ret
 35c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000360 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 360:	55                   	push   %ebp
 361:	89 e5                	mov    %esp,%ebp
 363:	57                   	push   %edi
 364:	8b 45 10             	mov    0x10(%ebp),%eax
 367:	8b 55 08             	mov    0x8(%ebp),%edx
 36a:	56                   	push   %esi
 36b:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
 36e:	85 c0                	test   %eax,%eax
 370:	7e 13                	jle    385 <memmove+0x25>
 372:	01 d0                	add    %edx,%eax
  dst = vdst;
 374:	89 d7                	mov    %edx,%edi
 376:	66 90                	xchg   %ax,%ax
 378:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 37f:	00 
    *dst++ = *src++;
 380:	a4                   	movsb  %ds:(%esi),%es:(%edi)
  while(n-- > 0)
 381:	39 f8                	cmp    %edi,%eax
 383:	75 fb                	jne    380 <memmove+0x20>
  return vdst;
}
 385:	5e                   	pop    %esi
 386:	89 d0                	mov    %edx,%eax
 388:	5f                   	pop    %edi
 389:	5d                   	pop    %ebp
 38a:	c3                   	ret

0000038b <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
 38b:	b8 01 00 00 00       	mov    $0x1,%eax
 390:	cd 40                	int    $0x40
 392:	c3                   	ret

00000393 <exit>:
SYSCALL(exit)
 393:	b8 02 00 00 00       	mov    $0x2,%eax
 398:	cd 40                	int    $0x40
 39a:	c3                   	ret

0000039b <wait>:
SYSCALL(wait)
 39b:	b8 03 00 00 00       	mov    $0x3,%eax
 3a0:	cd 40                	int    $0x40
 3a2:	c3                   	ret

000003a3 <pipe>:
SYSCALL(pipe)
 3a3:	b8 04 00 00 00       	mov    $0x4,%eax
 3a8:	cd 40                	int    $0x40
 3aa:	c3                   	ret

000003ab <read>:
SYSCALL(read)
 3ab:	b8 05 00 00 00       	mov    $0x5,%eax
 3b0:	cd 40                	int    $0x40
 3b2:	c3                   	ret

000003b3 <write>:
SYSCALL(write)
 3b3:	b8 10 00 00 00       	mov    $0x10,%eax
 3b8:	cd 40                	int    $0x40
 3ba:	c3                   	ret

000003bb <close>:
SYSCALL(close)
 3bb:	b8 15 00 00 00       	mov    $0x15,%eax
 3c0:	cd 40                	int    $0x40
 3c2:	c3                   	ret

000003c3 <kill>:
SYSCALL(kill)
 3c3:	b8 06 00 00 00       	mov    $0x6,%eax
 3c8:	cd 40                	int    $0x40
 3ca:	c3                   	ret

000003cb <exec>:
SYSCALL(exec)
 3cb:	b8 07 00 00 00       	mov    $0x7,%eax
 3d0:	cd 40                	int    $0x40
 3d2:	c3                   	ret

000003d3 <open>:
SYSCALL(open)
 3d3:	b8 0f 00 00 00       	mov    $0xf,%eax
 3d8:	cd 40                	int    $0x40
 3da:	c3                   	ret

000003db <mknod>:
SYSCALL(mknod)
 3db:	b8 11 00 00 00       	mov    $0x11,%eax
 3e0:	cd 40                	int    $0x40
 3e2:	c3                   	ret

000003e3 <unlink>:
SYSCALL(unlink)
 3e3:	b8 12 00 00 00       	mov    $0x12,%eax
 3e8:	cd 40                	int    $0x40
 3ea:	c3                   	ret

000003eb <fstat>:
SYSCALL(fstat)
 3eb:	b8 08 00 00 00       	mov    $0x8,%eax
 3f0:	cd 40                	int    $0x40
 3f2:	c3                   	ret

000003f3 <link>:
SYSCALL(link)
 3f3:	b8 13 00 00 00       	mov    $0x13,%eax
 3f8:	cd 40                	int    $0x40
 3fa:	c3                   	ret

000003fb <mkdir>:
SYSCALL(mkdir)
 3fb:	b8 14 00 00 00       	mov    $0x14,%eax
 400:	cd 40                	int    $0x40
 402:	c3                   	ret

00000403 <chdir>:
SYSCALL(chdir)
 403:	b8 09 00 00 00       	mov    $0x9,%eax
 408:	cd 40                	int    $0x40
 40a:	c3                   	ret

0000040b <dup>:
SYSCALL(dup)
 40b:	b8 0a 00 00 00       	mov    $0xa,%eax
 410:	cd 40                	int    $0x40
 412:	c3                   	ret

00000413 <getpid>:
SYSCALL(getpid)
 413:	b8 0b 00 00 00       	mov    $0xb,%eax
 418:	cd 40                	int    $0x40
 41a:	c3                   	ret

0000041b <sbrk>:
SYSCALL(sbrk)
 41b:	b8 0c 00 00 00       	mov    $0xc,%eax
 420:	cd 40                	int    $0x40
 422:	c3                   	ret

00000423 <sleep>:
SYSCALL(sleep)
 423:	b8 0d 00 00 00       	mov    $0xd,%eax
 428:	cd 40                	int    $0x40
 42a:	c3                   	ret

0000042b <uptime>:
SYSCALL(uptime)
 42b:	b8 0e 00 00 00       	mov    $0xe,%eax
 430:	cd 40                	int    $0x40
 432:	c3                   	ret

00000433 <vmprint>:

// Assignment 9 system calls
SYSCALL(vmprint)
 433:	b8 16 00 00 00       	mov    $0x16,%eax
 438:	cd 40                	int    $0x40
 43a:	c3                   	ret

0000043b <getfaults>:
SYSCALL(getfaults)
 43b:	b8 17 00 00 00       	mov    $0x17,%eax
 440:	cd 40                	int    $0x40
 442:	c3                   	ret

00000443 <memstats>:

// Assignment 10 system calls
SYSCALL(memstats)
 443:	b8 18 00 00 00       	mov    $0x18,%eax
 448:	cd 40                	int    $0x40
 44a:	c3                   	ret

0000044b <vtop>:
SYSCALL(vtop)
 44b:	b8 19 00 00 00       	mov    $0x19,%eax
 450:	cd 40                	int    $0x40
 452:	c3                   	ret

00000453 <pageinfo>:
SYSCALL(pageinfo)
 453:	b8 1a 00 00 00       	mov    $0x1a,%eax
 458:	cd 40                	int    $0x40
 45a:	c3                   	ret

0000045b <setreadonly>:
SYSCALL(setreadonly)
 45b:	b8 1b 00 00 00       	mov    $0x1b,%eax
 460:	cd 40                	int    $0x40
 462:	c3                   	ret
 463:	66 90                	xchg   %ax,%ax
 465:	66 90                	xchg   %ax,%ax
 467:	66 90                	xchg   %ax,%ax
 469:	66 90                	xchg   %ax,%ax
 46b:	66 90                	xchg   %ax,%ax
 46d:	66 90                	xchg   %ax,%ax
 46f:	66 90                	xchg   %ax,%ax
 471:	66 90                	xchg   %ax,%ax
 473:	66 90                	xchg   %ax,%ax
 475:	66 90                	xchg   %ax,%ax
 477:	66 90                	xchg   %ax,%ax
 479:	66 90                	xchg   %ax,%ax
 47b:	66 90                	xchg   %ax,%ax
 47d:	66 90                	xchg   %ax,%ax
 47f:	90                   	nop

00000480 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
 480:	55                   	push   %ebp
 481:	89 e5                	mov    %esp,%ebp
 483:	57                   	push   %edi
 484:	56                   	push   %esi
 485:	53                   	push   %ebx
 486:	89 cb                	mov    %ecx,%ebx
 488:	83 ec 3c             	sub    $0x3c,%esp
 48b:	89 45 c4             	mov    %eax,-0x3c(%ebp)
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 48e:	85 d2                	test   %edx,%edx
 490:	0f 89 9a 00 00 00    	jns    530 <printint+0xb0>
 496:	f6 45 08 01          	testb  $0x1,0x8(%ebp)
 49a:	0f 84 90 00 00 00    	je     530 <printint+0xb0>
    neg = 1;
    x = -xx;
 4a0:	f7 da                	neg    %edx
    neg = 1;
 4a2:	b8 01 00 00 00       	mov    $0x1,%eax
 4a7:	89 45 c0             	mov    %eax,-0x40(%ebp)
 4aa:	89 d1                	mov    %edx,%ecx
  } else {
    x = xx;
  }

  i = 0;
 4ac:	31 f6                	xor    %esi,%esi
 4ae:	66 90                	xchg   %ax,%ax
 4b0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 4b7:	00 
 4b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 4bf:	00 
  do{
    buf[i++] = digits[x % base];
 4c0:	89 c8                	mov    %ecx,%eax
 4c2:	31 d2                	xor    %edx,%edx
 4c4:	89 f7                	mov    %esi,%edi
 4c6:	f7 f3                	div    %ebx
 4c8:	8d 76 01             	lea    0x1(%esi),%esi
  }while((x /= base) != 0);
 4cb:	39 d9                	cmp    %ebx,%ecx
    buf[i++] = digits[x % base];
 4cd:	0f b6 92 c0 0a 00 00 	movzbl 0xac0(%edx),%edx
  }while((x /= base) != 0);
 4d4:	89 c1                	mov    %eax,%ecx
    buf[i++] = digits[x % base];
 4d6:	88 54 35 d7          	mov    %dl,-0x29(%ebp,%esi,1)
  }while((x /= base) != 0);
 4da:	73 e4                	jae    4c0 <printint+0x40>
  if(neg)
 4dc:	8b 45 c0             	mov    -0x40(%ebp),%eax
 4df:	85 c0                	test   %eax,%eax
 4e1:	74 07                	je     4ea <printint+0x6a>
    buf[i++] = '-';
 4e3:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)
 4e8:	89 f7                	mov    %esi,%edi

  while(--i >= 0)
 4ea:	8d 74 3d d8          	lea    -0x28(%ebp,%edi,1),%esi
 4ee:	8b 7d c4             	mov    -0x3c(%ebp),%edi
 4f1:	8d 5d d7             	lea    -0x29(%ebp),%ebx
 4f4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
 4f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 4ff:	00 
    putc(fd, buf[i]);
 500:	0f b6 06             	movzbl (%esi),%eax
  write(fd, &c, 1);
 503:	83 ec 04             	sub    $0x4,%esp
  while(--i >= 0)
 506:	83 ee 01             	sub    $0x1,%esi
 509:	88 45 d7             	mov    %al,-0x29(%ebp)
  write(fd, &c, 1);
 50c:	8d 45 d7             	lea    -0x29(%ebp),%eax
 50f:	6a 01                	push   $0x1
 511:	50                   	push   %eax
 512:	57                   	push   %edi
 513:	e8 9b fe ff ff       	call   3b3 <write>
  while(--i >= 0)
 518:	83 c4 10             	add    $0x10,%esp
 51b:	39 f3                	cmp    %esi,%ebx
 51d:	75 e1                	jne    500 <printint+0x80>
}
 51f:	8d 65 f4             	lea    -0xc(%ebp),%esp
 522:	5b                   	pop    %ebx
 523:	5e                   	pop    %esi
 524:	5f                   	pop    %edi
 525:	5d                   	pop    %ebp
 526:	c3                   	ret
 527:	90                   	nop
 528:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 52f:	00 
  neg = 0;
 530:	31 c0                	xor    %eax,%eax
 532:	e9 70 ff ff ff       	jmp    4a7 <printint+0x27>
 537:	90                   	nop
 538:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 53f:	00 

00000540 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
 540:	55                   	push   %ebp
 541:	89 e5                	mov    %esp,%ebp
 543:	57                   	push   %edi
 544:	56                   	push   %esi
 545:	53                   	push   %ebx
 546:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
 549:	8b 5d 0c             	mov    0xc(%ebp),%ebx
{
 54c:	8b 75 08             	mov    0x8(%ebp),%esi
  for(i = 0; fmt[i]; i++){
 54f:	0f b6 13             	movzbl (%ebx),%edx
 552:	83 c3 01             	add    $0x1,%ebx
 555:	84 d2                	test   %dl,%dl
 557:	0f 84 a0 00 00 00    	je     5fd <printf+0xbd>
 55d:	8d 45 10             	lea    0x10(%ebp),%eax
 560:	89 45 d4             	mov    %eax,-0x2c(%ebp)
    c = fmt[i] & 0xff;
 563:	8b 7d d4             	mov    -0x2c(%ebp),%edi
 566:	0f b6 c2             	movzbl %dl,%eax
    if(state == 0){
 569:	eb 28                	jmp    593 <printf+0x53>
 56b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  write(fd, &c, 1);
 570:	83 ec 04             	sub    $0x4,%esp
 573:	8d 45 e7             	lea    -0x19(%ebp),%eax
 576:	88 55 e7             	mov    %dl,-0x19(%ebp)
  for(i = 0; fmt[i]; i++){
 579:	83 c3 01             	add    $0x1,%ebx
  write(fd, &c, 1);
 57c:	6a 01                	push   $0x1
 57e:	50                   	push   %eax
 57f:	56                   	push   %esi
 580:	e8 2e fe ff ff       	call   3b3 <write>
  for(i = 0; fmt[i]; i++){
 585:	0f b6 53 ff          	movzbl -0x1(%ebx),%edx
 589:	83 c4 10             	add    $0x10,%esp
 58c:	84 d2                	test   %dl,%dl
 58e:	74 6d                	je     5fd <printf+0xbd>
    c = fmt[i] & 0xff;
 590:	0f b6 c2             	movzbl %dl,%eax
      if(c == '%'){
 593:	83 f8 25             	cmp    $0x25,%eax
 596:	75 d8                	jne    570 <printf+0x30>
  for(i = 0; fmt[i]; i++){
 598:	0f b6 13             	movzbl (%ebx),%edx
 59b:	84 d2                	test   %dl,%dl
 59d:	74 5e                	je     5fd <printf+0xbd>
    c = fmt[i] & 0xff;
 59f:	0f b6 c2             	movzbl %dl,%eax
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
      if(c == 'd'){
 5a2:	80 fa 25             	cmp    $0x25,%dl
 5a5:	0f 84 25 01 00 00    	je     6d0 <printf+0x190>
 5ab:	83 e8 63             	sub    $0x63,%eax
 5ae:	83 f8 15             	cmp    $0x15,%eax
 5b1:	77 0d                	ja     5c0 <printf+0x80>
 5b3:	ff 24 85 68 0a 00 00 	jmp    *0xa68(,%eax,4)
 5ba:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  write(fd, &c, 1);
 5c0:	83 ec 04             	sub    $0x4,%esp
 5c3:	8d 4d e7             	lea    -0x19(%ebp),%ecx
 5c6:	88 55 d0             	mov    %dl,-0x30(%ebp)
        ap++;
      } else if(c == '%'){
        putc(fd, c);
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
 5c9:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
  write(fd, &c, 1);
 5cd:	6a 01                	push   $0x1
 5cf:	51                   	push   %ecx
 5d0:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
 5d3:	56                   	push   %esi
 5d4:	e8 da fd ff ff       	call   3b3 <write>
        putc(fd, c);
 5d9:	0f b6 55 d0          	movzbl -0x30(%ebp),%edx
  write(fd, &c, 1);
 5dd:	83 c4 0c             	add    $0xc,%esp
 5e0:	88 55 e7             	mov    %dl,-0x19(%ebp)
 5e3:	6a 01                	push   $0x1
 5e5:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
 5e8:	51                   	push   %ecx
  for(i = 0; fmt[i]; i++){
 5e9:	83 c3 02             	add    $0x2,%ebx
  write(fd, &c, 1);
 5ec:	56                   	push   %esi
 5ed:	e8 c1 fd ff ff       	call   3b3 <write>
  for(i = 0; fmt[i]; i++){
 5f2:	0f b6 53 ff          	movzbl -0x1(%ebx),%edx
 5f6:	83 c4 10             	add    $0x10,%esp
 5f9:	84 d2                	test   %dl,%dl
 5fb:	75 93                	jne    590 <printf+0x50>
      }
      state = 0;
    }
  }
}
 5fd:	8d 65 f4             	lea    -0xc(%ebp),%esp
 600:	5b                   	pop    %ebx
 601:	5e                   	pop    %esi
 602:	5f                   	pop    %edi
 603:	5d                   	pop    %ebp
 604:	c3                   	ret
 605:	8d 76 00             	lea    0x0(%esi),%esi
        printint(fd, *ap, 16, 0);
 608:	83 ec 0c             	sub    $0xc,%esp
 60b:	8b 17                	mov    (%edi),%edx
 60d:	b9 10 00 00 00       	mov    $0x10,%ecx
 612:	89 f0                	mov    %esi,%eax
 614:	6a 00                	push   $0x0
 616:	e8 65 fe ff ff       	call   480 <printint>
  for(i = 0; fmt[i]; i++){
 61b:	0f b6 53 01          	movzbl 0x1(%ebx),%edx
 61f:	83 c3 02             	add    $0x2,%ebx
 622:	83 c4 10             	add    $0x10,%esp
 625:	84 d2                	test   %dl,%dl
 627:	74 d4                	je     5fd <printf+0xbd>
        ap++;
 629:	83 c7 04             	add    $0x4,%edi
 62c:	e9 5f ff ff ff       	jmp    590 <printf+0x50>
 631:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        s = (char*)*ap;
 638:	8b 07                	mov    (%edi),%eax
        ap++;
 63a:	83 c7 04             	add    $0x4,%edi
        if(s == 0)
 63d:	85 c0                	test   %eax,%eax
 63f:	0f 84 9b 00 00 00    	je     6e0 <printf+0x1a0>
        while(*s != 0){
 645:	0f b6 10             	movzbl (%eax),%edx
 648:	84 d2                	test   %dl,%dl
 64a:	0f 84 a2 00 00 00    	je     6f2 <printf+0x1b2>
 650:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 653:	89 c7                	mov    %eax,%edi
 655:	89 d0                	mov    %edx,%eax
 657:	89 5d d0             	mov    %ebx,-0x30(%ebp)
 65a:	89 fb                	mov    %edi,%ebx
 65c:	8d 7d e7             	lea    -0x19(%ebp),%edi
 65f:	90                   	nop
  write(fd, &c, 1);
 660:	83 ec 04             	sub    $0x4,%esp
 663:	88 45 e7             	mov    %al,-0x19(%ebp)
          s++;
 666:	83 c3 01             	add    $0x1,%ebx
  write(fd, &c, 1);
 669:	6a 01                	push   $0x1
 66b:	57                   	push   %edi
 66c:	56                   	push   %esi
 66d:	e8 41 fd ff ff       	call   3b3 <write>
        while(*s != 0){
 672:	0f b6 03             	movzbl (%ebx),%eax
 675:	83 c4 10             	add    $0x10,%esp
 678:	84 c0                	test   %al,%al
 67a:	75 e4                	jne    660 <printf+0x120>
 67c:	8b 5d d0             	mov    -0x30(%ebp),%ebx
  for(i = 0; fmt[i]; i++){
 67f:	0f b6 53 01          	movzbl 0x1(%ebx),%edx
 683:	83 c3 02             	add    $0x2,%ebx
 686:	84 d2                	test   %dl,%dl
 688:	0f 85 d5 fe ff ff    	jne    563 <printf+0x23>
 68e:	e9 6a ff ff ff       	jmp    5fd <printf+0xbd>
 693:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
        printint(fd, *ap, 10, 1);
 698:	83 ec 0c             	sub    $0xc,%esp
 69b:	8b 17                	mov    (%edi),%edx
 69d:	b9 0a 00 00 00       	mov    $0xa,%ecx
 6a2:	89 f0                	mov    %esi,%eax
 6a4:	6a 01                	push   $0x1
 6a6:	e8 d5 fd ff ff       	call   480 <printint>
  for(i = 0; fmt[i]; i++){
 6ab:	e9 6b ff ff ff       	jmp    61b <printf+0xdb>
        putc(fd, *ap);
 6b0:	8b 07                	mov    (%edi),%eax
  write(fd, &c, 1);
 6b2:	83 ec 04             	sub    $0x4,%esp
 6b5:	8d 4d e7             	lea    -0x19(%ebp),%ecx
        putc(fd, *ap);
 6b8:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
 6bb:	6a 01                	push   $0x1
 6bd:	51                   	push   %ecx
 6be:	56                   	push   %esi
 6bf:	e8 ef fc ff ff       	call   3b3 <write>
 6c4:	e9 52 ff ff ff       	jmp    61b <printf+0xdb>
 6c9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 6d0:	83 ec 04             	sub    $0x4,%esp
 6d3:	88 55 e7             	mov    %dl,-0x19(%ebp)
 6d6:	8d 4d e7             	lea    -0x19(%ebp),%ecx
 6d9:	6a 01                	push   $0x1
 6db:	e9 08 ff ff ff       	jmp    5e8 <printf+0xa8>
          s = "(null)";
 6e0:	89 7d d4             	mov    %edi,-0x2c(%ebp)
 6e3:	b8 28 00 00 00       	mov    $0x28,%eax
 6e8:	bf 5e 0a 00 00       	mov    $0xa5e,%edi
 6ed:	e9 65 ff ff ff       	jmp    657 <printf+0x117>
  for(i = 0; fmt[i]; i++){
 6f2:	0f b6 53 01          	movzbl 0x1(%ebx),%edx
 6f6:	83 c3 02             	add    $0x2,%ebx
 6f9:	84 d2                	test   %dl,%dl
 6fb:	0f 85 8f fe ff ff    	jne    590 <printf+0x50>
 701:	e9 f7 fe ff ff       	jmp    5fd <printf+0xbd>
 706:	66 90                	xchg   %ax,%ax
 708:	66 90                	xchg   %ax,%ax
 70a:	66 90                	xchg   %ax,%ax
 70c:	66 90                	xchg   %ax,%ax
 70e:	66 90                	xchg   %ax,%ax
 710:	66 90                	xchg   %ax,%ax
 712:	66 90                	xchg   %ax,%ax
 714:	66 90                	xchg   %ax,%ax
 716:	66 90                	xchg   %ax,%ax
 718:	66 90                	xchg   %ax,%ax
 71a:	66 90                	xchg   %ax,%ax
 71c:	66 90                	xchg   %ax,%ax
 71e:	66 90                	xchg   %ax,%ax

00000720 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 720:	55                   	push   %ebp
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 721:	a1 6c 0d 00 00       	mov    0xd6c,%eax
{
 726:	89 e5                	mov    %esp,%ebp
 728:	57                   	push   %edi
 729:	56                   	push   %esi
 72a:	53                   	push   %ebx
 72b:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = (Header*)ap - 1;
 72e:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 731:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
 738:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 73f:	00 
 740:	89 c2                	mov    %eax,%edx
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 742:	8b 00                	mov    (%eax),%eax
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 744:	39 ca                	cmp    %ecx,%edx
 746:	73 30                	jae    778 <free+0x58>
 748:	39 c1                	cmp    %eax,%ecx
 74a:	72 04                	jb     750 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 74c:	39 c2                	cmp    %eax,%edx
 74e:	72 f0                	jb     740 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 750:	8b 73 fc             	mov    -0x4(%ebx),%esi
 753:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 756:	39 f8                	cmp    %edi,%eax
 758:	74 36                	je     790 <free+0x70>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 75a:	89 43 f8             	mov    %eax,-0x8(%ebx)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 75d:	8b 42 04             	mov    0x4(%edx),%eax
 760:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 763:	39 f1                	cmp    %esi,%ecx
 765:	74 40                	je     7a7 <free+0x87>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 767:	89 0a                	mov    %ecx,(%edx)
  } else
    p->s.ptr = bp;
  freep = p;
}
 769:	5b                   	pop    %ebx
  freep = p;
 76a:	89 15 6c 0d 00 00    	mov    %edx,0xd6c
}
 770:	5e                   	pop    %esi
 771:	5f                   	pop    %edi
 772:	5d                   	pop    %ebp
 773:	c3                   	ret
 774:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 778:	39 c2                	cmp    %eax,%edx
 77a:	72 c4                	jb     740 <free+0x20>
 77c:	39 c1                	cmp    %eax,%ecx
 77e:	73 c0                	jae    740 <free+0x20>
  if(bp + bp->s.size == p->s.ptr){
 780:	8b 73 fc             	mov    -0x4(%ebx),%esi
 783:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
 786:	39 f8                	cmp    %edi,%eax
 788:	75 d0                	jne    75a <free+0x3a>
 78a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    bp->s.size += p->s.ptr->s.size;
 790:	03 70 04             	add    0x4(%eax),%esi
 793:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
 796:	8b 02                	mov    (%edx),%eax
 798:	8b 00                	mov    (%eax),%eax
 79a:	89 43 f8             	mov    %eax,-0x8(%ebx)
  if(p + p->s.size == bp){
 79d:	8b 42 04             	mov    0x4(%edx),%eax
 7a0:	8d 34 c2             	lea    (%edx,%eax,8),%esi
 7a3:	39 f1                	cmp    %esi,%ecx
 7a5:	75 c0                	jne    767 <free+0x47>
    p->s.size += bp->s.size;
 7a7:	03 43 fc             	add    -0x4(%ebx),%eax
  freep = p;
 7aa:	89 15 6c 0d 00 00    	mov    %edx,0xd6c
    p->s.size += bp->s.size;
 7b0:	89 42 04             	mov    %eax,0x4(%edx)
    p->s.ptr = bp->s.ptr;
 7b3:	8b 4b f8             	mov    -0x8(%ebx),%ecx
 7b6:	89 0a                	mov    %ecx,(%edx)
}
 7b8:	5b                   	pop    %ebx
 7b9:	5e                   	pop    %esi
 7ba:	5f                   	pop    %edi
 7bb:	5d                   	pop    %ebp
 7bc:	c3                   	ret
 7bd:	8d 76 00             	lea    0x0(%esi),%esi

000007c0 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 7c0:	55                   	push   %ebp
 7c1:	89 e5                	mov    %esp,%ebp
 7c3:	57                   	push   %edi
 7c4:	56                   	push   %esi
 7c5:	53                   	push   %ebx
 7c6:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 7c9:	8b 45 08             	mov    0x8(%ebp),%eax
  if((prevp = freep) == 0){
 7cc:	8b 15 6c 0d 00 00    	mov    0xd6c,%edx
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 7d2:	8d 78 07             	lea    0x7(%eax),%edi
 7d5:	c1 ef 03             	shr    $0x3,%edi
 7d8:	83 c7 01             	add    $0x1,%edi
  if((prevp = freep) == 0){
 7db:	85 d2                	test   %edx,%edx
 7dd:	0f 84 8d 00 00 00    	je     870 <malloc+0xb0>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 7e3:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 7e5:	8b 48 04             	mov    0x4(%eax),%ecx
 7e8:	39 f9                	cmp    %edi,%ecx
 7ea:	73 64                	jae    850 <malloc+0x90>
  if(nu < 4096)
 7ec:	bb 00 10 00 00       	mov    $0x1000,%ebx
 7f1:	39 df                	cmp    %ebx,%edi
 7f3:	0f 43 df             	cmovae %edi,%ebx
  p = sbrk(nu * sizeof(Header));
 7f6:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
 7fd:	eb 0a                	jmp    809 <malloc+0x49>
 7ff:	90                   	nop
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 800:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
 802:	8b 48 04             	mov    0x4(%eax),%ecx
 805:	39 f9                	cmp    %edi,%ecx
 807:	73 47                	jae    850 <malloc+0x90>
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 809:	89 c2                	mov    %eax,%edx
 80b:	39 05 6c 0d 00 00    	cmp    %eax,0xd6c
 811:	75 ed                	jne    800 <malloc+0x40>
  p = sbrk(nu * sizeof(Header));
 813:	83 ec 0c             	sub    $0xc,%esp
 816:	56                   	push   %esi
 817:	e8 ff fb ff ff       	call   41b <sbrk>
  if(p == (char*)-1)
 81c:	83 c4 10             	add    $0x10,%esp
 81f:	83 f8 ff             	cmp    $0xffffffff,%eax
 822:	74 1c                	je     840 <malloc+0x80>
  hp->s.size = nu;
 824:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
 827:	83 ec 0c             	sub    $0xc,%esp
 82a:	83 c0 08             	add    $0x8,%eax
 82d:	50                   	push   %eax
 82e:	e8 ed fe ff ff       	call   720 <free>
  return freep;
 833:	8b 15 6c 0d 00 00    	mov    0xd6c,%edx
      if((p = morecore(nunits)) == 0)
 839:	83 c4 10             	add    $0x10,%esp
 83c:	85 d2                	test   %edx,%edx
 83e:	75 c0                	jne    800 <malloc+0x40>
        return 0;
  }
}
 840:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return 0;
 843:	31 c0                	xor    %eax,%eax
}
 845:	5b                   	pop    %ebx
 846:	5e                   	pop    %esi
 847:	5f                   	pop    %edi
 848:	5d                   	pop    %ebp
 849:	c3                   	ret
 84a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      if(p->s.size == nunits)
 850:	39 cf                	cmp    %ecx,%edi
 852:	74 4c                	je     8a0 <malloc+0xe0>
        p->s.size -= nunits;
 854:	29 f9                	sub    %edi,%ecx
 856:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
 859:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
 85c:	89 78 04             	mov    %edi,0x4(%eax)
      freep = prevp;
 85f:	89 15 6c 0d 00 00    	mov    %edx,0xd6c
}
 865:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return (void*)(p + 1);
 868:	83 c0 08             	add    $0x8,%eax
}
 86b:	5b                   	pop    %ebx
 86c:	5e                   	pop    %esi
 86d:	5f                   	pop    %edi
 86e:	5d                   	pop    %ebp
 86f:	c3                   	ret
    base.s.ptr = freep = prevp = &base;
 870:	c7 05 6c 0d 00 00 70 	movl   $0xd70,0xd6c
 877:	0d 00 00 
    base.s.size = 0;
 87a:	b8 70 0d 00 00       	mov    $0xd70,%eax
    base.s.ptr = freep = prevp = &base;
 87f:	c7 05 70 0d 00 00 70 	movl   $0xd70,0xd70
 886:	0d 00 00 
    base.s.size = 0;
 889:	c7 05 74 0d 00 00 00 	movl   $0x0,0xd74
 890:	00 00 00 
    if(p->s.size >= nunits){
 893:	e9 54 ff ff ff       	jmp    7ec <malloc+0x2c>
 898:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
 89f:	00 
        prevp->s.ptr = p->s.ptr;
 8a0:	8b 08                	mov    (%eax),%ecx
 8a2:	89 0a                	mov    %ecx,(%edx)
 8a4:	eb b9                	jmp    85f <malloc+0x9f>
