#include "types.h"
#include "user.h"

#define PGSIZE 4096

int
main(void)
{
  char *base;
  uint start;
  int i;

  printf(1, "Q1: Page table before reserving four pages\n");
  vmprint();

  base = sbrk(4 * PGSIZE);
  if(base == (char*)-1){
    printf(1, "pttest: sbrk failed\n");
    exit();
  }

  // Q2 changes sbrk to reserve virtual space lazily. Touch one byte in
  // each distinct page so the final page table has exactly four new pages.
  start = ((uint)base + PGSIZE - 1) & ~(PGSIZE - 1);
  for(i = 0; i < 4; i++)
    *((char*)(start + i * PGSIZE)) = (char)i;

  printf(1, "\nQ1: Page table after touching four new pages\n");
  vmprint();
  printf(1, "pttest: four reserved pages were touched\n");
  exit();
}
