# Operating Systems Lab — Assignment 10 (xv6 x86)

This package is a standalone classic **xv6-public x86** source tree with the four Assignment 10 questions implemented. It is based on the clean, buildable Assignment 9 xv6 tree so the existing lazy-allocation page-fault path is retained for the read-only protection demonstration.

## Included Assignment 10 work

### Q1 — Physical page allocation tracking
- `kalloc.c` now counts successful runtime `kalloc()` operations and runtime `kfree()` operations.
- `printmemstats()` reports total allocated, total freed, currently allocated (`allocated - freed`), and available free-list pages.
- `memstats()` is system call 24.
- `memtest.c` reserves three pages with `sbrk()`, touches each page (important because this tree has lazy allocation), displays statistics, releases the range, and displays statistics again.

**Counter semantics:** boot-time free-list construction in `kinit1()`/`kinit2()` is intentionally not counted as a runtime free. Counters begin once `kinit2()` enables allocator locking. This avoids treating the boot-time creation of the initial free list as pages freed by a running process. Statistics are global to the kernel, not per-process.

### Q2 — Virtual-to-physical translation
- `vtop(int virtual_address)` is system call 25.
- It uses `walkpgdir()` to find a present user PTE, extracts `PTE_ADDR(*pte)`, and adds the page offset.
- It returns `-1` for an unmapped, non-user, or kernel virtual address.
- `vttest.c` allocates and touches two pages, translates addresses with different offsets, and tests an unmapped user-range address.

### Q3 — Page information and read-only protection
- `pageinfo(int virtual_address)` is system call 26. It prints the physical frame number and P/W/U bits.
- `setreadonly(int virtual_address)` is system call 27. It clears `PTE_W` and reloads CR3 to flush cached translations for the current process.
- `pagetest.c` maps a page, displays its flags, removes write permission, displays the flags again, then forks a child that attempts the protected write. The child is expected to be terminated by the existing page-fault handling; the parent survives.

### Q4 — FIFO, LRU, Optimal page replacement
- `pagereplace.c` accepts a frame count and a space-separated reference string.
- For each algorithm it prints every reference, frame state, and HIT/FAULT result.
- It also prints a comparison for 3, 4, and 5 frames: faults, hits, hit ratio, and page-fault ratio.

## System call numbers

The Assignment 9 base already uses 22 (`vmprint`) and 23 (`getfaults`). Assignment 10 adds:

| System call | Number |
|---|---:|
| `memstats` | 24 |
| `vtop` | 25 |
| `pageinfo` | 26 |
| `setreadonly` | 27 |

The declarations, dispatcher entries, wrappers, and assembly stubs are updated consistently in `syscall.h`, `syscall.c`, `sysproc.c`, `user.h`, and `usys.S`.

## Build on Ubuntu

From this directory:

```sh
make clean
make TOOLPREFIX=
make fs.img TOOLPREFIX=
```

Run xv6 (QEMU must be installed):

```sh
make CPUS=1 qemu-nox
```

At the xv6 shell:

```text
$ memtest
$ vttest
$ pagetest
$ pagereplace
```

For `pagereplace`, enter `3` for the detailed trace frame count, then enter:

```text
7 0 1 2 0 3 0 4 2 3 0 3 2 1 2 0 1 7 0 1
```

Expected 3-frame page faults for this reference string:
- FIFO: 15
- LRU: 12
- Optimal: 9

Expected 3/4/5-frame comparison is in `output_logs/EXPECTED_Q4_RESULTS.txt`.

## Verification status and submission note

The kernel build (`make TOOLPREFIX=`) and filesystem/user-program build (`make fs.img TOOLPREFIX=`) completed successfully in the packaging environment. QEMU was not available there, so runtime execution and terminal screenshots have not been fabricated. Run all four programs in QEMU on your machine and capture genuine terminal screenshots for submission. See `SUBMISSION_CHECKLIST.md`.
