# Assignment 10 Submission Checklist

- [x] Kernel allocator counters and `memstats()` system call implemented.
- [x] `memtest.c` added to the xv6 filesystem.
- [x] `vtop()` system call and `vttest.c` implemented.
- [x] `pageinfo()` and `setreadonly()` system calls implemented.
- [x] `pagetest.c` read-only write test uses a child process.
- [x] FIFO, LRU, and Optimal implemented in `pagereplace.c`.
- [x] Required programs added to `UPROGS` in the Makefile.
- [x] Kernel build verified.
- [x] Filesystem/user-program build verified.
- [ ] Run `memtest` in QEMU and capture a screenshot.
- [ ] Run `vttest` in QEMU and capture a screenshot.
- [ ] Run `pagetest` in QEMU and capture a screenshot.
- [ ] Run `pagereplace` in QEMU and capture a screenshot.
- [ ] Add the genuine screenshots to the final submission.
- [ ] Review and personalize `REPORT_ASSIGNMENT10.md` based on your observed output.
