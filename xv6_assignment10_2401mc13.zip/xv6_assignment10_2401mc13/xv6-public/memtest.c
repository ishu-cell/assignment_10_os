#include "types.h"
#include "user.h"

#define PGSIZE 4096

int
main(void)
{
  int i;
  int pages = 3;
  volatile char *mem;

  printf(1, "Assignment 10 - Q1: physical memory statistics\n");
  printf(1, "Before sbrk():\n");
  memstats();

  mem = (volatile char*)sbrk(pages * PGSIZE);
  if(mem == (char*)-1){
    printf(1, "memtest: sbrk allocation failed\n");
    exit();
  }

  // This xv6 tree also supports lazy allocation. Touch one byte in each
  // reserved page so that each page is backed by a physical frame.
  for(i = 0; i < pages; i++)
    mem[i * PGSIZE] = (char)(i + 1);

  printf(1, "\nAfter reserving and touching %d pages:\n", pages);
  memstats();

  if(sbrk(-pages * PGSIZE) == (char*)-1){
    printf(1, "memtest: sbrk release failed\n");
    exit();
  }

  printf(1, "\nAfter releasing the %d pages:\n", pages);
  memstats();
  exit();
}
