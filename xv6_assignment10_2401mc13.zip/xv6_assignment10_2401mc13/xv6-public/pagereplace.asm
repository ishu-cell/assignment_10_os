
_pagereplace:     file format elf32-i386


Disassembly of section .text:

00000000 <main>:
  return faults;
}

int
main(void)
{
       0:	8d 4c 24 04          	lea    0x4(%esp),%ecx
       4:	83 e4 f0             	and    $0xfffffff0,%esp
       7:	ff 71 fc             	push   -0x4(%ecx)
       a:	55                   	push   %ebp
       b:	89 e5                	mov    %esp,%ebp
       d:	57                   	push   %edi
       e:	56                   	push   %esi
       f:	53                   	push   %ebx
      10:	51                   	push   %ecx
      11:	81 ec c0 03 00 00    	sub    $0x3c0,%esp
  int refs[MAXREF];
  int n, nf, hits;
  int h3, h4, h5;
  int ff, fl, fo;

  printf(1, "Assignment 10 - Q4: FIFO, LRU and Optimal page replacement\n");
      17:	68 04 12 00 00       	push   $0x1204
      1c:	6a 01                	push   $0x1
      1e:	e8 7d 0d 00 00       	call   da0 <printf>
  printf(1, "Enter frame count for detailed trace (1-%d): ", MAXF);
      23:	83 c4 0c             	add    $0xc,%esp
      26:	6a 0a                	push   $0xa
      28:	68 40 12 00 00       	push   $0x1240
      2d:	6a 01                	push   $0x1
      2f:	e8 6c 0d 00 00       	call   da0 <printf>
  if(gets(line, sizeof(line)) == 0){
      34:	5e                   	pop    %esi
      35:	8d b5 e8 fd ff ff    	lea    -0x218(%ebp),%esi
      3b:	5f                   	pop    %edi
      3c:	68 00 02 00 00       	push   $0x200
      41:	56                   	push   %esi
      42:	e8 69 0a 00 00       	call   ab0 <gets>
      47:	83 c4 10             	add    $0x10,%esp
      4a:	85 c0                	test   %eax,%eax
      4c:	0f 84 cb 02 00 00    	je     31d <main+0x31d>
    printf(1, "No frame count received.\n");
    exit();
  }
  nf = atoi(line);
      52:	83 ec 0c             	sub    $0xc,%esp
      55:	56                   	push   %esi
      56:	e8 15 0b 00 00       	call   b70 <atoi>
  if(nf < 1 || nf > MAXF){
      5b:	83 c4 10             	add    $0x10,%esp
  nf = atoi(line);
      5e:	89 c3                	mov    %eax,%ebx
  if(nf < 1 || nf > MAXF){
      60:	8d 40 ff             	lea    -0x1(%eax),%eax
      63:	83 f8 09             	cmp    $0x9,%eax
      66:	77 7f                	ja     e7 <main+0xe7>
    printf(1, "Invalid frame count. Use 1 through %d.\n", MAXF);
    exit();
  }

  printf(1, "Enter space-separated page reference string:\n");
      68:	50                   	push   %eax
      69:	50                   	push   %eax
      6a:	68 98 12 00 00       	push   $0x1298
      6f:	6a 01                	push   $0x1
      71:	e8 2a 0d 00 00       	call   da0 <printf>
  if(gets(line, sizeof(line)) == 0){
      76:	58                   	pop    %eax
      77:	5a                   	pop    %edx
      78:	68 00 02 00 00       	push   $0x200
      7d:	56                   	push   %esi
      7e:	e8 2d 0a 00 00       	call   ab0 <gets>
      83:	83 c4 10             	add    $0x10,%esp
      86:	85 c0                	test   %eax,%eax
      88:	0f 84 a2 02 00 00    	je     330 <main+0x330>
  int n = 0;
      8e:	31 c0                	xor    %eax,%eax
  char *p = line;
      90:	89 f2                	mov    %esi,%edx
      92:	be 13 00 80 00       	mov    $0x800013,%esi
  int n = 0;
      97:	89 85 44 fc ff ff    	mov    %eax,-0x3bc(%ebp)
  while(*p){
      9d:	80 bd e8 fd ff ff 00 	cmpb   $0x0,-0x218(%ebp)
      a4:	74 2d                	je     d3 <main+0xd3>
      a6:	89 9d 40 fc ff ff    	mov    %ebx,-0x3c0(%ebp)
      ac:	eb 15                	jmp    c3 <main+0xc3>
      ae:	66 90                	xchg   %ax,%ax
      b0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
      b7:	00 
      b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
      bf:	00 
      p++;
      c0:	83 c2 01             	add    $0x1,%edx
    while(*p == ' ' || *p == '\t' || *p == '\r' || *p == '\n')
      c3:	0f b6 02             	movzbl (%edx),%eax
      c6:	8d 48 f7             	lea    -0x9(%eax),%ecx
      c9:	80 f9 17             	cmp    $0x17,%cl
      cc:	77 32                	ja     100 <main+0x100>
      ce:	0f a3 ce             	bt     %ecx,%esi
      d1:	72 ed                	jb     c0 <main+0xc0>
    printf(1, "No reference string received.\n");
    exit();
  }
  n = parse_refs(line, refs);
  if(n <= 0){
    printf(1, "Invalid reference string (maximum %d references).\n", MAXREF);
      d3:	57                   	push   %edi
      d4:	6a 64                	push   $0x64
      d6:	68 c8 12 00 00       	push   $0x12c8
      db:	6a 01                	push   $0x1
      dd:	e8 be 0c 00 00       	call   da0 <printf>
    exit();
      e2:	e8 0c 0b 00 00       	call   bf3 <exit>
    printf(1, "Invalid frame count. Use 1 through %d.\n", MAXF);
      e7:	51                   	push   %ecx
      e8:	6a 0a                	push   $0xa
      ea:	68 70 12 00 00       	push   $0x1270
      ef:	6a 01                	push   $0x1
      f1:	e8 aa 0c 00 00       	call   da0 <printf>
    exit();
      f6:	e8 f8 0a 00 00       	call   bf3 <exit>
      fb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
    if(*p == 0)
     100:	84 c0                	test   %al,%al
     102:	0f 84 3b 02 00 00    	je     343 <main+0x343>
    if(*p < '0' || *p > '9')
     108:	8d 48 d0             	lea    -0x30(%eax),%ecx
     10b:	80 f9 09             	cmp    $0x9,%cl
     10e:	77 c3                	ja     d3 <main+0xd3>
    int value = 0;
     110:	8b bd 40 fc ff ff    	mov    -0x3c0(%ebp),%edi
     116:	31 c9                	xor    %ecx,%ecx
     118:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     11f:	00 
      value = value * 10 + (*p - '0');
     120:	83 e8 30             	sub    $0x30,%eax
     123:	8d 0c 89             	lea    (%ecx,%ecx,4),%ecx
      p++;
     126:	83 c2 01             	add    $0x1,%edx
      value = value * 10 + (*p - '0');
     129:	0f be c0             	movsbl %al,%eax
     12c:	8d 0c 48             	lea    (%eax,%ecx,2),%ecx
    while(*p >= '0' && *p <= '9'){
     12f:	0f b6 02             	movzbl (%edx),%eax
     132:	8d 58 d0             	lea    -0x30(%eax),%ebx
     135:	80 fb 09             	cmp    $0x9,%bl
     138:	76 e6                	jbe    120 <main+0x120>
    if(n >= MAXREF)
     13a:	8b 9d 44 fc ff ff    	mov    -0x3bc(%ebp),%ebx
     140:	89 bd 40 fc ff ff    	mov    %edi,-0x3c0(%ebp)
     146:	83 fb 64             	cmp    $0x64,%ebx
     149:	74 88                	je     d3 <main+0xd3>
    refs[n++] = value;
     14b:	8d bd 58 fc ff ff    	lea    -0x3a8(%ebp),%edi
     151:	89 0c 9f             	mov    %ecx,(%edi,%ebx,4)
    if(*p && *p != ' ' && *p != '\t' && *p != '\r' && *p != '\n')
     154:	a8 df                	test   $0xdf,%al
     156:	74 20                	je     178 <main+0x178>
     158:	3c 0a                	cmp    $0xa,%al
     15a:	0f 8f b0 01 00 00    	jg     310 <main+0x310>
     160:	3c 08                	cmp    $0x8,%al
     162:	0f 8e 6b ff ff ff    	jle    d3 <main+0xd3>
    refs[n++] = value;
     168:	83 85 44 fc ff ff 01 	addl   $0x1,-0x3bc(%ebp)
     16f:	e9 4f ff ff ff       	jmp    c3 <main+0xc3>
     174:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
     178:	83 85 44 fc ff ff 01 	addl   $0x1,-0x3bc(%ebp)
  while(*p){
     17f:	84 c0                	test   %al,%al
     181:	0f 85 3c ff ff ff    	jne    c3 <main+0xc3>
     187:	8b 9d 40 fc ff ff    	mov    -0x3c0(%ebp),%ebx
  }
  printf(1, "References=%d, detailed trace frames=%d\n", n, nf);
     18d:	53                   	push   %ebx
     18e:	ff b5 44 fc ff ff    	push   -0x3bc(%ebp)
     194:	68 1c 13 00 00       	push   $0x131c
     199:	6a 01                	push   $0x1
     19b:	e8 00 0c 00 00       	call   da0 <printf>

  run_fifo(refs, n, nf, 1, &hits);
     1a0:	59                   	pop    %ecx
     1a1:	5e                   	pop    %esi
     1a2:	8d b5 48 fc ff ff    	lea    -0x3b8(%ebp),%esi
     1a8:	56                   	push   %esi
     1a9:	8b 95 44 fc ff ff    	mov    -0x3bc(%ebp),%edx
     1af:	89 d9                	mov    %ebx,%ecx
     1b1:	89 f8                	mov    %edi,%eax
     1b3:	6a 01                	push   $0x1
     1b5:	e8 56 02 00 00       	call   410 <run_fifo>
  run_lru(refs, n, nf, 1, &hits);
     1ba:	58                   	pop    %eax
     1bb:	5a                   	pop    %edx
     1bc:	56                   	push   %esi
     1bd:	6a 01                	push   $0x1
     1bf:	8b 95 44 fc ff ff    	mov    -0x3bc(%ebp),%edx
     1c5:	89 d9                	mov    %ebx,%ecx
     1c7:	89 f8                	mov    %edi,%eax
     1c9:	e8 a2 03 00 00       	call   570 <run_lru>
  run_opt(refs, n, nf, 1, &hits);
     1ce:	59                   	pop    %ecx
     1cf:	58                   	pop    %eax
     1d0:	56                   	push   %esi
     1d1:	8b b5 44 fc ff ff    	mov    -0x3bc(%ebp),%esi
     1d7:	6a 01                	push   $0x1
     1d9:	89 d9                	mov    %ebx,%ecx
     1db:	89 f8                	mov    %edi,%eax
     1dd:	89 f2                	mov    %esi,%edx
     1df:	e8 5c 05 00 00       	call   740 <run_opt>

  printf(1, "\n--- Comparison for 3, 4 and 5 frames ---\n");
     1e4:	58                   	pop    %eax
     1e5:	5a                   	pop    %edx
     1e6:	68 48 13 00 00       	push   $0x1348
     1eb:	6a 01                	push   $0x1
     1ed:	e8 ae 0b 00 00       	call   da0 <printf>
  printf(1, "Frames Alg      Faults Hits HitRatio FaultRatio\n");
     1f2:	59                   	pop    %ecx
     1f3:	5b                   	pop    %ebx
     1f4:	68 74 13 00 00       	push   $0x1374
     1f9:	6a 01                	push   $0x1
  for(nf = 3; nf <= 5; nf++){
     1fb:	bb 03 00 00 00       	mov    $0x3,%ebx
  printf(1, "Frames Alg      Faults Hits HitRatio FaultRatio\n");
     200:	e8 9b 0b 00 00       	call   da0 <printf>
     205:	83 c4 10             	add    $0x10,%esp
     208:	89 bd 44 fc ff ff    	mov    %edi,-0x3bc(%ebp)
    ff = run_fifo(refs, n, nf, 0, &h3);
     20e:	8d 85 4c fc ff ff    	lea    -0x3b4(%ebp),%eax
     214:	52                   	push   %edx
     215:	89 d9                	mov    %ebx,%ecx
     217:	52                   	push   %edx
     218:	89 f2                	mov    %esi,%edx
     21a:	50                   	push   %eax
     21b:	8b 85 44 fc ff ff    	mov    -0x3bc(%ebp),%eax
     221:	6a 00                	push   $0x0
     223:	e8 e8 01 00 00       	call   410 <run_fifo>
    fl = run_lru(refs, n, nf, 0, &h4);
     228:	8d 95 50 fc ff ff    	lea    -0x3b0(%ebp),%edx
     22e:	59                   	pop    %ecx
     22f:	89 d9                	mov    %ebx,%ecx
    ff = run_fifo(refs, n, nf, 0, &h3);
     231:	89 c7                	mov    %eax,%edi
    fl = run_lru(refs, n, nf, 0, &h4);
     233:	58                   	pop    %eax
     234:	8b 85 44 fc ff ff    	mov    -0x3bc(%ebp),%eax
     23a:	52                   	push   %edx
     23b:	6a 00                	push   $0x0
     23d:	89 f2                	mov    %esi,%edx
     23f:	e8 2c 03 00 00       	call   570 <run_lru>
    fo = run_opt(refs, n, nf, 0, &h5);
     244:	89 d9                	mov    %ebx,%ecx
    fl = run_lru(refs, n, nf, 0, &h4);
     246:	89 85 40 fc ff ff    	mov    %eax,-0x3c0(%ebp)
    fo = run_opt(refs, n, nf, 0, &h5);
     24c:	58                   	pop    %eax
     24d:	5a                   	pop    %edx
     24e:	8d 95 54 fc ff ff    	lea    -0x3ac(%ebp),%edx
     254:	8b 85 44 fc ff ff    	mov    -0x3bc(%ebp),%eax
     25a:	52                   	push   %edx
     25b:	89 f2                	mov    %esi,%edx
     25d:	6a 00                	push   $0x0
     25f:	e8 dc 04 00 00       	call   740 <run_opt>
    printf(1, "%d      FIFO     %d      %d    %d%%      %d%%\n",
           nf, ff, h3, h3 * 100 / n, ff * 100 / n);
     264:	8b 8d 4c fc ff ff    	mov    -0x3b4(%ebp),%ecx
    printf(1, "%d      FIFO     %d      %d    %d%%      %d%%\n",
     26a:	83 c4 0c             	add    $0xc,%esp
    fo = run_opt(refs, n, nf, 0, &h5);
     26d:	89 85 3c fc ff ff    	mov    %eax,-0x3c4(%ebp)
           nf, ff, h3, h3 * 100 / n, ff * 100 / n);
     273:	6b c7 64             	imul   $0x64,%edi,%eax
    printf(1, "%d      FIFO     %d      %d    %d%%      %d%%\n",
     276:	99                   	cltd
     277:	f7 fe                	idiv   %esi
     279:	50                   	push   %eax
           nf, ff, h3, h3 * 100 / n, ff * 100 / n);
     27a:	6b c1 64             	imul   $0x64,%ecx,%eax
    printf(1, "%d      FIFO     %d      %d    %d%%      %d%%\n",
     27d:	99                   	cltd
     27e:	f7 fe                	idiv   %esi
     280:	50                   	push   %eax
     281:	51                   	push   %ecx
     282:	57                   	push   %edi
     283:	53                   	push   %ebx
     284:	68 a8 13 00 00       	push   $0x13a8
     289:	6a 01                	push   $0x1
     28b:	e8 10 0b 00 00       	call   da0 <printf>
    printf(1, "%d      LRU      %d      %d    %d%%      %d%%\n",
           nf, fl, h4, h4 * 100 / n, fl * 100 / n);
     290:	8b bd 40 fc ff ff    	mov    -0x3c0(%ebp),%edi
     296:	8b 8d 50 fc ff ff    	mov    -0x3b0(%ebp),%ecx
    printf(1, "%d      LRU      %d      %d    %d%%      %d%%\n",
     29c:	83 c4 1c             	add    $0x1c,%esp
           nf, fl, h4, h4 * 100 / n, fl * 100 / n);
     29f:	6b c7 64             	imul   $0x64,%edi,%eax
    printf(1, "%d      LRU      %d      %d    %d%%      %d%%\n",
     2a2:	99                   	cltd
     2a3:	f7 fe                	idiv   %esi
     2a5:	50                   	push   %eax
           nf, fl, h4, h4 * 100 / n, fl * 100 / n);
     2a6:	6b c1 64             	imul   $0x64,%ecx,%eax
    printf(1, "%d      LRU      %d      %d    %d%%      %d%%\n",
     2a9:	99                   	cltd
     2aa:	f7 fe                	idiv   %esi
     2ac:	50                   	push   %eax
     2ad:	51                   	push   %ecx
     2ae:	57                   	push   %edi
     2af:	53                   	push   %ebx
     2b0:	68 d8 13 00 00       	push   $0x13d8
     2b5:	6a 01                	push   $0x1
     2b7:	e8 e4 0a 00 00       	call   da0 <printf>
    printf(1, "%d      Optimal  %d      %d    %d%%      %d%%\n",
           nf, fo, h5, h5 * 100 / n, fo * 100 / n);
     2bc:	8b bd 3c fc ff ff    	mov    -0x3c4(%ebp),%edi
     2c2:	8b 8d 54 fc ff ff    	mov    -0x3ac(%ebp),%ecx
    printf(1, "%d      Optimal  %d      %d    %d%%      %d%%\n",
     2c8:	83 c4 1c             	add    $0x1c,%esp
           nf, fo, h5, h5 * 100 / n, fo * 100 / n);
     2cb:	6b c7 64             	imul   $0x64,%edi,%eax
    printf(1, "%d      Optimal  %d      %d    %d%%      %d%%\n",
     2ce:	99                   	cltd
     2cf:	f7 fe                	idiv   %esi
     2d1:	50                   	push   %eax
           nf, fo, h5, h5 * 100 / n, fo * 100 / n);
     2d2:	6b c1 64             	imul   $0x64,%ecx,%eax
    printf(1, "%d      Optimal  %d      %d    %d%%      %d%%\n",
     2d5:	99                   	cltd
     2d6:	f7 fe                	idiv   %esi
     2d8:	50                   	push   %eax
     2d9:	51                   	push   %ecx
     2da:	57                   	push   %edi
     2db:	53                   	push   %ebx
  for(nf = 3; nf <= 5; nf++){
     2dc:	83 c3 01             	add    $0x1,%ebx
    printf(1, "%d      Optimal  %d      %d    %d%%      %d%%\n",
     2df:	68 08 14 00 00       	push   $0x1408
     2e4:	6a 01                	push   $0x1
     2e6:	e8 b5 0a 00 00       	call   da0 <printf>
  for(nf = 3; nf <= 5; nf++){
     2eb:	83 c4 20             	add    $0x20,%esp
     2ee:	83 fb 06             	cmp    $0x6,%ebx
     2f1:	0f 85 17 ff ff ff    	jne    20e <main+0x20e>
  }
  printf(1, "Optimal gives the minimum possible faults for this known string.\n");
     2f7:	50                   	push   %eax
     2f8:	50                   	push   %eax
     2f9:	68 38 14 00 00       	push   $0x1438
     2fe:	6a 01                	push   $0x1
     300:	e8 9b 0a 00 00       	call   da0 <printf>
  exit();
     305:	e8 e9 08 00 00       	call   bf3 <exit>
     30a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
     310:	3c 0d                	cmp    $0xd,%al
     312:	0f 84 50 fe ff ff    	je     168 <main+0x168>
     318:	e9 b6 fd ff ff       	jmp    d3 <main+0xd3>
    printf(1, "No frame count received.\n");
     31d:	53                   	push   %ebx
     31e:	53                   	push   %ebx
     31f:	68 7c 11 00 00       	push   $0x117c
     324:	6a 01                	push   $0x1
     326:	e8 75 0a 00 00       	call   da0 <printf>
    exit();
     32b:	e8 c3 08 00 00       	call   bf3 <exit>
    printf(1, "No reference string received.\n");
     330:	56                   	push   %esi
     331:	56                   	push   %esi
     332:	68 fc 12 00 00       	push   $0x12fc
     337:	6a 01                	push   $0x1
     339:	e8 62 0a 00 00       	call   da0 <printf>
    exit();
     33e:	e8 b0 08 00 00       	call   bf3 <exit>
  if(n <= 0){
     343:	8b 9d 40 fc ff ff    	mov    -0x3c0(%ebp),%ebx
     349:	83 bd 44 fc ff ff 00 	cmpl   $0x0,-0x3bc(%ebp)
     350:	0f 84 7d fd ff ff    	je     d3 <main+0xd3>
     356:	8d bd 58 fc ff ff    	lea    -0x3a8(%ebp),%edi
     35c:	e9 2c fe ff ff       	jmp    18d <main+0x18d>
     361:	66 90                	xchg   %ax,%ax
     363:	66 90                	xchg   %ax,%ax
     365:	66 90                	xchg   %ax,%ax
     367:	66 90                	xchg   %ax,%ax
     369:	66 90                	xchg   %ax,%ax
     36b:	66 90                	xchg   %ax,%ax
     36d:	66 90                	xchg   %ax,%ax
     36f:	66 90                	xchg   %ax,%ax
     371:	66 90                	xchg   %ax,%ax
     373:	66 90                	xchg   %ax,%ax
     375:	66 90                	xchg   %ax,%ax
     377:	66 90                	xchg   %ax,%ax
     379:	66 90                	xchg   %ax,%ax
     37b:	66 90                	xchg   %ax,%ax
     37d:	66 90                	xchg   %ax,%ax
     37f:	90                   	nop

00000380 <print_frames>:
{
     380:	55                   	push   %ebp
     381:	89 e5                	mov    %esp,%ebp
     383:	57                   	push   %edi
     384:	89 c7                	mov    %eax,%edi
     386:	56                   	push   %esi
     387:	89 d6                	mov    %edx,%esi
     389:	53                   	push   %ebx
     38a:	31 db                	xor    %ebx,%ebx
     38c:	83 ec 14             	sub    $0x14,%esp
  printf(1, "[");
     38f:	68 08 11 00 00       	push   $0x1108
     394:	6a 01                	push   $0x1
     396:	e8 05 0a 00 00       	call   da0 <printf>
    if(i)
     39b:	83 c4 10             	add    $0x10,%esp
     39e:	eb 2c                	jmp    3cc <print_frames+0x4c>
      printf(1, "%d", frames[i]);
     3a0:	83 ec 04             	sub    $0x4,%esp
  for(i = 0; i < nf; i++){
     3a3:	83 c3 01             	add    $0x1,%ebx
      printf(1, "%d", frames[i]);
     3a6:	50                   	push   %eax
     3a7:	68 0c 11 00 00       	push   $0x110c
     3ac:	6a 01                	push   $0x1
     3ae:	e8 ed 09 00 00       	call   da0 <printf>
     3b3:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < nf; i++){
     3b6:	39 de                	cmp    %ebx,%esi
     3b8:	74 32                	je     3ec <print_frames+0x6c>
      printf(1, " ");
     3ba:	83 ec 08             	sub    $0x8,%esp
     3bd:	68 1e 11 00 00       	push   $0x111e
     3c2:	6a 01                	push   $0x1
     3c4:	e8 d7 09 00 00       	call   da0 <printf>
     3c9:	83 c4 10             	add    $0x10,%esp
    if(frames[i] < 0)
     3cc:	8b 04 9f             	mov    (%edi,%ebx,4),%eax
     3cf:	85 c0                	test   %eax,%eax
     3d1:	79 cd                	jns    3a0 <print_frames+0x20>
      printf(1, "-");
     3d3:	83 ec 08             	sub    $0x8,%esp
  for(i = 0; i < nf; i++){
     3d6:	83 c3 01             	add    $0x1,%ebx
      printf(1, "-");
     3d9:	68 0a 11 00 00       	push   $0x110a
     3de:	6a 01                	push   $0x1
     3e0:	e8 bb 09 00 00       	call   da0 <printf>
     3e5:	83 c4 10             	add    $0x10,%esp
  for(i = 0; i < nf; i++){
     3e8:	39 de                	cmp    %ebx,%esi
     3ea:	75 ce                	jne    3ba <print_frames+0x3a>
  printf(1, "]");
     3ec:	83 ec 08             	sub    $0x8,%esp
     3ef:	68 0f 11 00 00       	push   $0x110f
     3f4:	6a 01                	push   $0x1
     3f6:	e8 a5 09 00 00       	call   da0 <printf>
}
     3fb:	83 c4 10             	add    $0x10,%esp
     3fe:	8d 65 f4             	lea    -0xc(%ebp),%esp
     401:	5b                   	pop    %ebx
     402:	5e                   	pop    %esi
     403:	5f                   	pop    %edi
     404:	5d                   	pop    %ebp
     405:	c3                   	ret
     406:	66 90                	xchg   %ax,%ax
     408:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     40f:	00 

00000410 <run_fifo>:
{
     410:	55                   	push   %ebp
     411:	89 e5                	mov    %esp,%ebp
     413:	57                   	push   %edi
     414:	89 c7                	mov    %eax,%edi
     416:	56                   	push   %esi
     417:	8d 75 c0             	lea    -0x40(%ebp),%esi
     41a:	53                   	push   %ebx
     41b:	89 cb                	mov    %ecx,%ebx
     41d:	89 f0                	mov    %esi,%eax
     41f:	8d 0c 8e             	lea    (%esi,%ecx,4),%ecx
     422:	83 ec 4c             	sub    $0x4c,%esp
     425:	f6 c3 01             	test   $0x1,%bl
     428:	74 16                	je     440 <run_fifo+0x30>
  for(i = 0; i < nf; i++)
     42a:	8d 45 c4             	lea    -0x3c(%ebp),%eax
    frames[i] = -1;
     42d:	c7 06 ff ff ff ff    	movl   $0xffffffff,(%esi)
  for(i = 0; i < nf; i++)
     433:	39 c1                	cmp    %eax,%ecx
     435:	74 1d                	je     454 <run_fifo+0x44>
     437:	90                   	nop
     438:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     43f:	00 
    frames[i] = -1;
     440:	c7 00 ff ff ff ff    	movl   $0xffffffff,(%eax)
  for(i = 0; i < nf; i++)
     446:	83 c0 08             	add    $0x8,%eax
    frames[i] = -1;
     449:	c7 40 fc ff ff ff ff 	movl   $0xffffffff,-0x4(%eax)
  for(i = 0; i < nf; i++)
     450:	39 c1                	cmp    %eax,%ecx
     452:	75 ec                	jne    440 <run_fifo+0x30>
  if(trace)
     454:	8b 4d 08             	mov    0x8(%ebp),%ecx
     457:	85 c9                	test   %ecx,%ecx
     459:	0f 85 cc 00 00 00    	jne    52b <run_fifo+0x11b>
  for(i = 0; i < n; i++){
     45f:	8d 04 97             	lea    (%edi,%edx,4),%eax
{
     462:	c7 45 b0 00 00 00 00 	movl   $0x0,-0x50(%ebp)
     469:	89 45 b4             	mov    %eax,-0x4c(%ebp)
     46c:	c7 45 a8 00 00 00 00 	movl   $0x0,-0x58(%ebp)
     473:	c7 45 ac 00 00 00 00 	movl   $0x0,-0x54(%ebp)
     47a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    j = find_page(frames, nf, refs[i]);
     480:	8b 0f                	mov    (%edi),%ecx
  for(i = 0; i < nf; i++)
     482:	31 c0                	xor    %eax,%eax
     484:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
     488:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     48f:	00 
    if(frames[i] == page)
     490:	3b 0c 86             	cmp    (%esi,%eax,4),%ecx
     493:	74 4b                	je     4e0 <run_fifo+0xd0>
  for(i = 0; i < nf; i++)
     495:	83 c0 01             	add    $0x1,%eax
     498:	39 c3                	cmp    %eax,%ebx
     49a:	75 f4                	jne    490 <run_fifo+0x80>
      frames[next] = refs[i];
     49c:	8b 45 ac             	mov    -0x54(%ebp),%eax
      faults++;
     49f:	83 45 a8 01          	addl   $0x1,-0x58(%ebp)
      frames[next] = refs[i];
     4a3:	89 4c 85 c0          	mov    %ecx,-0x40(%ebp,%eax,4)
      next = (next + 1) % nf;
     4a7:	83 c0 01             	add    $0x1,%eax
     4aa:	99                   	cltd
     4ab:	f7 fb                	idiv   %ebx
     4ad:	89 55 ac             	mov    %edx,-0x54(%ebp)
      if(trace){
     4b0:	8b 55 08             	mov    0x8(%ebp),%edx
     4b3:	85 d2                	test   %edx,%edx
     4b5:	75 69                	jne    520 <run_fifo+0x110>
  for(i = 0; i < n; i++){
     4b7:	83 c7 04             	add    $0x4,%edi
     4ba:	39 7d b4             	cmp    %edi,-0x4c(%ebp)
     4bd:	75 c1                	jne    480 <run_fifo+0x70>
  if(trace)
     4bf:	8b 4d 08             	mov    0x8(%ebp),%ecx
     4c2:	85 c9                	test   %ecx,%ecx
     4c4:	0f 85 7f 00 00 00    	jne    549 <run_fifo+0x139>
  *hits_out = hits;
     4ca:	8b 45 0c             	mov    0xc(%ebp),%eax
     4cd:	8b 55 b0             	mov    -0x50(%ebp),%edx
     4d0:	89 10                	mov    %edx,(%eax)
}
     4d2:	8b 45 a8             	mov    -0x58(%ebp),%eax
     4d5:	8d 65 f4             	lea    -0xc(%ebp),%esp
     4d8:	5b                   	pop    %ebx
     4d9:	5e                   	pop    %esi
     4da:	5f                   	pop    %edi
     4db:	5d                   	pop    %ebp
     4dc:	c3                   	ret
     4dd:	8d 76 00             	lea    0x0(%esi),%esi
      if(trace){
     4e0:	8b 45 08             	mov    0x8(%ebp),%eax
      hits++;
     4e3:	83 45 b0 01          	addl   $0x1,-0x50(%ebp)
      if(trace){
     4e7:	85 c0                	test   %eax,%eax
     4e9:	74 cc                	je     4b7 <run_fifo+0xa7>
        printf(1, "ref %d: HIT   ", refs[i]);
     4eb:	83 ec 04             	sub    $0x4,%esp
     4ee:	51                   	push   %ecx
     4ef:	68 11 11 00 00       	push   $0x1111
        printf(1, "ref %d: FAULT ", refs[i]);
     4f4:	6a 01                	push   $0x1
     4f6:	e8 a5 08 00 00       	call   da0 <printf>
        print_frames(frames, nf);
     4fb:	89 da                	mov    %ebx,%edx
     4fd:	89 f0                	mov    %esi,%eax
     4ff:	e8 7c fe ff ff       	call   380 <print_frames>
        printf(1, "\n");
     504:	58                   	pop    %eax
     505:	5a                   	pop    %edx
     506:	68 94 11 00 00       	push   $0x1194
     50b:	6a 01                	push   $0x1
     50d:	e8 8e 08 00 00       	call   da0 <printf>
     512:	83 c4 10             	add    $0x10,%esp
     515:	eb a0                	jmp    4b7 <run_fifo+0xa7>
     517:	90                   	nop
     518:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     51f:	00 
        printf(1, "ref %d: FAULT ", refs[i]);
     520:	83 ec 04             	sub    $0x4,%esp
     523:	51                   	push   %ecx
     524:	68 20 11 00 00       	push   $0x1120
     529:	eb c9                	jmp    4f4 <run_fifo+0xe4>
    printf(1, "\n--- FIFO with %d frame(s) ---\n", nf);
     52b:	83 ec 04             	sub    $0x4,%esp
     52e:	89 55 b4             	mov    %edx,-0x4c(%ebp)
     531:	53                   	push   %ebx
     532:	68 a0 11 00 00       	push   $0x11a0
     537:	6a 01                	push   $0x1
     539:	e8 62 08 00 00       	call   da0 <printf>
     53e:	8b 55 b4             	mov    -0x4c(%ebp),%edx
     541:	83 c4 10             	add    $0x10,%esp
     544:	e9 16 ff ff ff       	jmp    45f <run_fifo+0x4f>
    printf(1, "FIFO: faults=%d hits=%d\n", faults, hits);
     549:	ff 75 b0             	push   -0x50(%ebp)
     54c:	ff 75 a8             	push   -0x58(%ebp)
     54f:	68 2f 11 00 00       	push   $0x112f
     554:	6a 01                	push   $0x1
     556:	e8 45 08 00 00       	call   da0 <printf>
     55b:	83 c4 10             	add    $0x10,%esp
     55e:	e9 67 ff ff ff       	jmp    4ca <run_fifo+0xba>
     563:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
     568:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     56f:	00 

00000570 <run_lru>:
{
     570:	55                   	push   %ebp
     571:	89 e5                	mov    %esp,%ebp
     573:	57                   	push   %edi
     574:	56                   	push   %esi
     575:	53                   	push   %ebx
     576:	8d 5d 98             	lea    -0x68(%ebp),%ebx
     579:	83 ec 7c             	sub    $0x7c,%esp
     57c:	89 55 90             	mov    %edx,-0x70(%ebp)
     57f:	89 45 94             	mov    %eax,-0x6c(%ebp)
     582:	89 c8                	mov    %ecx,%eax
  for(i = 0; i < nf; i++){
     584:	31 c9                	xor    %ecx,%ecx
     586:	eb 18                	jmp    5a0 <run_lru+0x30>
     588:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     58f:	00 
     590:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     597:	00 
     598:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     59f:	00 
    frames[i] = -1;
     5a0:	c7 04 8b ff ff ff ff 	movl   $0xffffffff,(%ebx,%ecx,4)
    last[i] = -1;
     5a7:	89 cf                	mov    %ecx,%edi
     5a9:	c7 44 8d c0 ff ff ff 	movl   $0xffffffff,-0x40(%ebp,%ecx,4)
     5b0:	ff 
  for(i = 0; i < nf; i++){
     5b1:	83 c1 01             	add    $0x1,%ecx
     5b4:	39 c8                	cmp    %ecx,%eax
     5b6:	75 e8                	jne    5a0 <run_lru+0x30>
  if(trace)
     5b8:	8b 75 08             	mov    0x8(%ebp),%esi
     5bb:	85 f6                	test   %esi,%esi
     5bd:	0f 85 42 01 00 00    	jne    705 <run_lru+0x195>
  for(i = 0; i < nf; i++){
     5c3:	c7 45 8c 00 00 00 00 	movl   $0x0,-0x74(%ebp)
     5ca:	31 f6                	xor    %esi,%esi
     5cc:	c7 45 84 00 00 00 00 	movl   $0x0,-0x7c(%ebp)
     5d3:	89 4d 88             	mov    %ecx,-0x78(%ebp)
     5d6:	66 90                	xchg   %ax,%ax
     5d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     5df:	00 
    j = find_page(frames, nf, refs[i]);
     5e0:	8b 45 94             	mov    -0x6c(%ebp),%eax
  for(i = 0; i < nf; i++)
     5e3:	31 d2                	xor    %edx,%edx
    j = find_page(frames, nf, refs[i]);
     5e5:	8b 04 b0             	mov    (%eax,%esi,4),%eax
  for(i = 0; i < nf; i++)
     5e8:	eb 09                	jmp    5f3 <run_lru+0x83>
     5ea:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
     5f0:	83 c2 01             	add    $0x1,%edx
    if(frames[i] == page)
     5f3:	3b 04 93             	cmp    (%ebx,%edx,4),%eax
     5f6:	0f 84 a4 00 00 00    	je     6a0 <run_lru+0x130>
  for(i = 0; i < nf; i++)
     5fc:	39 d7                	cmp    %edx,%edi
     5fe:	75 f0                	jne    5f0 <run_lru+0x80>
      faults++;
     600:	83 45 84 01          	addl   $0x1,-0x7c(%ebp)
      for(k = 0; k < nf; k++)
     604:	31 d2                	xor    %edx,%edx
     606:	eb 0b                	jmp    613 <run_lru+0xa3>
     608:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     60f:	00 
     610:	83 c2 01             	add    $0x1,%edx
        if(frames[k] < 0){ victim = k; break; }
     613:	8b 0c 93             	mov    (%ebx,%edx,4),%ecx
     616:	85 c9                	test   %ecx,%ecx
     618:	78 62                	js     67c <run_lru+0x10c>
      for(k = 0; k < nf; k++)
     61a:	39 d7                	cmp    %edx,%edi
     61c:	75 f2                	jne    610 <run_lru+0xa0>
        victim = 0;
     61e:	31 d2                	xor    %edx,%edx
        for(k = 1; k < nf; k++)
     620:	83 7d 88 01          	cmpl   $0x1,-0x78(%ebp)
     624:	74 56                	je     67c <run_lru+0x10c>
        oldest = last[0];
     626:	8b 4d c0             	mov    -0x40(%ebp),%ecx
     629:	89 85 7c ff ff ff    	mov    %eax,-0x84(%ebp)
        victim = 0;
     62f:	31 d2                	xor    %edx,%edx
        oldest = last[0];
     631:	89 4d 80             	mov    %ecx,-0x80(%ebp)
        for(k = 1; k < nf; k++)
     634:	b9 01 00 00 00       	mov    $0x1,%ecx
     639:	8b 45 80             	mov    -0x80(%ebp),%eax
     63c:	89 75 80             	mov    %esi,-0x80(%ebp)
     63f:	eb 22                	jmp    663 <run_lru+0xf3>
     641:	eb 1d                	jmp    660 <run_lru+0xf0>
     643:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
     648:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     64f:	00 
     650:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     657:	00 
     658:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     65f:	00 
     660:	83 c1 01             	add    $0x1,%ecx
          if(last[k] < oldest){ oldest = last[k]; victim = k; }
     663:	8b 74 8d c0          	mov    -0x40(%ebp,%ecx,4),%esi
     667:	39 c6                	cmp    %eax,%esi
     669:	0f 4c c6             	cmovl  %esi,%eax
     66c:	0f 4c d1             	cmovl  %ecx,%edx
        for(k = 1; k < nf; k++)
     66f:	39 f9                	cmp    %edi,%ecx
     671:	75 ed                	jne    660 <run_lru+0xf0>
     673:	8b 85 7c ff ff ff    	mov    -0x84(%ebp),%eax
     679:	8b 75 80             	mov    -0x80(%ebp),%esi
      if(trace){
     67c:	8b 4d 08             	mov    0x8(%ebp),%ecx
      frames[victim] = refs[i];
     67f:	89 44 95 98          	mov    %eax,-0x68(%ebp,%edx,4)
      last[victim] = i;
     683:	89 74 95 c0          	mov    %esi,-0x40(%ebp,%edx,4)
      if(trace){
     687:	85 c9                	test   %ecx,%ecx
     689:	74 24                	je     6af <run_lru+0x13f>
        printf(1, "ref %d: FAULT ", refs[i]);
     68b:	83 ec 04             	sub    $0x4,%esp
     68e:	50                   	push   %eax
     68f:	68 20 11 00 00       	push   $0x1120
     694:	eb 4b                	jmp    6e1 <run_lru+0x171>
     696:	66 90                	xchg   %ax,%ax
     698:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     69f:	00 
      last[j] = i;
     6a0:	89 74 95 c0          	mov    %esi,-0x40(%ebp,%edx,4)
      if(trace){
     6a4:	8b 55 08             	mov    0x8(%ebp),%edx
      hits++;
     6a7:	83 45 8c 01          	addl   $0x1,-0x74(%ebp)
      if(trace){
     6ab:	85 d2                	test   %edx,%edx
     6ad:	75 29                	jne    6d8 <run_lru+0x168>
  for(i = 0; i < n; i++){
     6af:	83 c6 01             	add    $0x1,%esi
     6b2:	39 75 90             	cmp    %esi,-0x70(%ebp)
     6b5:	0f 85 25 ff ff ff    	jne    5e0 <run_lru+0x70>
  if(trace)
     6bb:	8b 4d 08             	mov    0x8(%ebp),%ecx
     6be:	85 c9                	test   %ecx,%ecx
     6c0:	75 61                	jne    723 <run_lru+0x1b3>
  *hits_out = hits;
     6c2:	8b 45 0c             	mov    0xc(%ebp),%eax
     6c5:	8b 4d 8c             	mov    -0x74(%ebp),%ecx
     6c8:	89 08                	mov    %ecx,(%eax)
}
     6ca:	8b 45 84             	mov    -0x7c(%ebp),%eax
     6cd:	8d 65 f4             	lea    -0xc(%ebp),%esp
     6d0:	5b                   	pop    %ebx
     6d1:	5e                   	pop    %esi
     6d2:	5f                   	pop    %edi
     6d3:	5d                   	pop    %ebp
     6d4:	c3                   	ret
     6d5:	8d 76 00             	lea    0x0(%esi),%esi
        printf(1, "ref %d: HIT   ", refs[i]);
     6d8:	83 ec 04             	sub    $0x4,%esp
     6db:	50                   	push   %eax
     6dc:	68 11 11 00 00       	push   $0x1111
        printf(1, "ref %d: FAULT ", refs[i]);
     6e1:	6a 01                	push   $0x1
     6e3:	e8 b8 06 00 00       	call   da0 <printf>
        print_frames(frames, nf);
     6e8:	8b 55 88             	mov    -0x78(%ebp),%edx
     6eb:	89 d8                	mov    %ebx,%eax
     6ed:	e8 8e fc ff ff       	call   380 <print_frames>
        printf(1, "\n");
     6f2:	58                   	pop    %eax
     6f3:	5a                   	pop    %edx
     6f4:	68 94 11 00 00       	push   $0x1194
     6f9:	6a 01                	push   $0x1
     6fb:	e8 a0 06 00 00       	call   da0 <printf>
     700:	83 c4 10             	add    $0x10,%esp
     703:	eb aa                	jmp    6af <run_lru+0x13f>
    printf(1, "\n--- LRU with %d frame(s) ---\n", nf);
     705:	83 ec 04             	sub    $0x4,%esp
     708:	51                   	push   %ecx
     709:	89 4d 8c             	mov    %ecx,-0x74(%ebp)
     70c:	68 c0 11 00 00       	push   $0x11c0
     711:	6a 01                	push   $0x1
     713:	e8 88 06 00 00       	call   da0 <printf>
     718:	8b 4d 8c             	mov    -0x74(%ebp),%ecx
     71b:	83 c4 10             	add    $0x10,%esp
     71e:	e9 a0 fe ff ff       	jmp    5c3 <run_lru+0x53>
    printf(1, "LRU: faults=%d hits=%d\n", faults, hits);
     723:	ff 75 8c             	push   -0x74(%ebp)
     726:	ff 75 84             	push   -0x7c(%ebp)
     729:	68 48 11 00 00       	push   $0x1148
     72e:	6a 01                	push   $0x1
     730:	e8 6b 06 00 00       	call   da0 <printf>
     735:	83 c4 10             	add    $0x10,%esp
     738:	eb 88                	jmp    6c2 <run_lru+0x152>
     73a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi

00000740 <run_opt>:
{
     740:	55                   	push   %ebp
     741:	89 e5                	mov    %esp,%ebp
     743:	57                   	push   %edi
     744:	56                   	push   %esi
     745:	8d 7d c0             	lea    -0x40(%ebp),%edi
     748:	89 ce                	mov    %ecx,%esi
     74a:	53                   	push   %ebx
     74b:	83 ec 6c             	sub    $0x6c,%esp
     74e:	89 55 b4             	mov    %edx,-0x4c(%ebp)
     751:	8d 14 8f             	lea    (%edi,%ecx,4),%edx
     754:	83 e1 01             	and    $0x1,%ecx
     757:	89 45 b0             	mov    %eax,-0x50(%ebp)
     75a:	89 f8                	mov    %edi,%eax
     75c:	74 22                	je     780 <run_opt+0x40>
  for(i = 0; i < nf; i++)
     75e:	8d 45 c4             	lea    -0x3c(%ebp),%eax
    frames[i] = -1;
     761:	c7 07 ff ff ff ff    	movl   $0xffffffff,(%edi)
  for(i = 0; i < nf; i++)
     767:	39 d0                	cmp    %edx,%eax
     769:	74 29                	je     794 <run_opt+0x54>
     76b:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
     770:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     777:	00 
     778:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     77f:	00 
    frames[i] = -1;
     780:	c7 00 ff ff ff ff    	movl   $0xffffffff,(%eax)
  for(i = 0; i < nf; i++)
     786:	83 c0 08             	add    $0x8,%eax
    frames[i] = -1;
     789:	c7 40 fc ff ff ff ff 	movl   $0xffffffff,-0x4(%eax)
  for(i = 0; i < nf; i++)
     790:	39 d0                	cmp    %edx,%eax
     792:	75 ec                	jne    780 <run_opt+0x40>
  if(trace)
     794:	8b 4d 08             	mov    0x8(%ebp),%ecx
     797:	85 c9                	test   %ecx,%ecx
     799:	0f 85 85 01 00 00    	jne    924 <run_opt+0x1e4>
{
     79f:	c7 45 ac 00 00 00 00 	movl   $0x0,-0x54(%ebp)
     7a6:	31 db                	xor    %ebx,%ebx
     7a8:	c7 45 a0 00 00 00 00 	movl   $0x0,-0x60(%ebp)
     7af:	90                   	nop
    j = find_page(frames, nf, refs[i]);
     7b0:	8b 45 b0             	mov    -0x50(%ebp),%eax
  for(i = 0; i < nf; i++)
     7b3:	31 d2                	xor    %edx,%edx
    j = find_page(frames, nf, refs[i]);
     7b5:	8b 04 98             	mov    (%eax,%ebx,4),%eax
  for(i = 0; i < nf; i++)
     7b8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     7bf:	00 
    if(frames[i] == page)
     7c0:	3b 04 97             	cmp    (%edi,%edx,4),%eax
     7c3:	0f 84 f7 00 00 00    	je     8c0 <run_opt+0x180>
  for(i = 0; i < nf; i++)
     7c9:	83 c2 01             	add    $0x1,%edx
     7cc:	39 d6                	cmp    %edx,%esi
     7ce:	75 f0                	jne    7c0 <run_opt+0x80>
      faults++;
     7d0:	83 45 a0 01          	addl   $0x1,-0x60(%ebp)
        farthest = next_use(refs, n, frames[0], i + 1);
     7d4:	83 c3 01             	add    $0x1,%ebx
      for(k = 0; k < nf; k++)
     7d7:	31 c9                	xor    %ecx,%ecx
     7d9:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        if(frames[k] < 0){ victim = k; break; }
     7e0:	8b 14 8f             	mov    (%edi,%ecx,4),%edx
     7e3:	85 d2                	test   %edx,%edx
     7e5:	0f 88 bd 00 00 00    	js     8a8 <run_opt+0x168>
      for(k = 0; k < nf; k++)
     7eb:	83 c1 01             	add    $0x1,%ecx
     7ee:	39 ce                	cmp    %ecx,%esi
     7f0:	75 ee                	jne    7e0 <run_opt+0xa0>
  for(i = from; i < n; i++)
     7f2:	89 5d a8             	mov    %ebx,-0x58(%ebp)
        farthest = next_use(refs, n, frames[0], i + 1);
     7f5:	8b 55 c0             	mov    -0x40(%ebp),%edx
  for(i = from; i < n; i++)
     7f8:	39 5d b4             	cmp    %ebx,-0x4c(%ebp)
     7fb:	0f 8e 58 01 00 00    	jle    959 <run_opt+0x219>
     801:	89 45 a4             	mov    %eax,-0x5c(%ebp)
     804:	8b 4d b0             	mov    -0x50(%ebp),%ecx
     807:	89 d8                	mov    %ebx,%eax
     809:	89 5d 9c             	mov    %ebx,-0x64(%ebp)
     80c:	8b 5d b4             	mov    -0x4c(%ebp),%ebx
     80f:	eb 1a                	jmp    82b <run_opt+0xeb>
     811:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
     818:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     81f:	00 
     820:	83 c0 01             	add    $0x1,%eax
     823:	39 c3                	cmp    %eax,%ebx
     825:	0f 84 28 01 00 00    	je     953 <run_opt+0x213>
    if(refs[i] == page)
     82b:	3b 14 81             	cmp    (%ecx,%eax,4),%edx
     82e:	75 f0                	jne    820 <run_opt+0xe0>
     830:	89 45 a8             	mov    %eax,-0x58(%ebp)
     833:	8b 5d 9c             	mov    -0x64(%ebp),%ebx
     836:	8b 45 a4             	mov    -0x5c(%ebp),%eax
        for(k = 1; k < nf; k++){
     839:	83 fe 01             	cmp    $0x1,%esi
     83c:	0f 84 36 01 00 00    	je     978 <run_opt+0x238>
     842:	89 45 94             	mov    %eax,-0x6c(%ebp)
     845:	8b 55 b4             	mov    -0x4c(%ebp),%edx
     848:	c7 45 a4 00 00 00 00 	movl   $0x0,-0x5c(%ebp)
     84f:	89 5d 9c             	mov    %ebx,-0x64(%ebp)
     852:	8b 5d b0             	mov    -0x50(%ebp),%ebx
     855:	89 75 98             	mov    %esi,-0x68(%ebp)
     858:	be 01 00 00 00       	mov    $0x1,%esi
     85d:	8d 76 00             	lea    0x0(%esi),%esi
  for(i = from; i < n; i++)
     860:	8b 45 9c             	mov    -0x64(%ebp),%eax
     863:	39 c2                	cmp    %eax,%edx
     865:	0f 8e 05 01 00 00    	jle    970 <run_opt+0x230>
          when = next_use(refs, n, frames[k], i + 1);
     86b:	8b 0c b7             	mov    (%edi,%esi,4),%ecx
     86e:	eb 0b                	jmp    87b <run_opt+0x13b>
  for(i = from; i < n; i++)
     870:	83 c0 01             	add    $0x1,%eax
     873:	39 c2                	cmp    %eax,%edx
     875:	0f 84 f5 00 00 00    	je     970 <run_opt+0x230>
    if(refs[i] == page)
     87b:	3b 0c 83             	cmp    (%ebx,%eax,4),%ecx
     87e:	75 f0                	jne    870 <run_opt+0x130>
          if(when > farthest){ farthest = when; victim = k; }
     880:	8b 4d a8             	mov    -0x58(%ebp),%ecx
     883:	39 c8                	cmp    %ecx,%eax
     885:	0f 4e c1             	cmovle %ecx,%eax
     888:	89 45 a8             	mov    %eax,-0x58(%ebp)
     88b:	8b 45 a4             	mov    -0x5c(%ebp),%eax
     88e:	0f 4f c6             	cmovg  %esi,%eax
        for(k = 1; k < nf; k++){
     891:	83 c6 01             	add    $0x1,%esi
          if(when > farthest){ farthest = when; victim = k; }
     894:	89 45 a4             	mov    %eax,-0x5c(%ebp)
        for(k = 1; k < nf; k++){
     897:	39 75 98             	cmp    %esi,-0x68(%ebp)
     89a:	75 c4                	jne    860 <run_opt+0x120>
     89c:	8b 45 94             	mov    -0x6c(%ebp),%eax
     89f:	8b 4d a4             	mov    -0x5c(%ebp),%ecx
     8a2:	8b 5d 9c             	mov    -0x64(%ebp),%ebx
     8a5:	8b 75 98             	mov    -0x68(%ebp),%esi
      frames[victim] = refs[i];
     8a8:	89 44 8d c0          	mov    %eax,-0x40(%ebp,%ecx,4)
      if(trace){
     8ac:	8b 4d 08             	mov    0x8(%ebp),%ecx
     8af:	85 c9                	test   %ecx,%ecx
     8b1:	74 1b                	je     8ce <run_opt+0x18e>
        printf(1, "ref %d: FAULT ", refs[i]);
     8b3:	83 ec 04             	sub    $0x4,%esp
     8b6:	50                   	push   %eax
     8b7:	68 20 11 00 00       	push   $0x1120
     8bc:	eb 43                	jmp    901 <run_opt+0x1c1>
     8be:	66 90                	xchg   %ax,%ax
      if(trace){
     8c0:	8b 55 08             	mov    0x8(%ebp),%edx
      hits++;
     8c3:	83 45 ac 01          	addl   $0x1,-0x54(%ebp)
        farthest = next_use(refs, n, frames[0], i + 1);
     8c7:	83 c3 01             	add    $0x1,%ebx
      if(trace){
     8ca:	85 d2                	test   %edx,%edx
     8cc:	75 2a                	jne    8f8 <run_opt+0x1b8>
  for(i = 0; i < n; i++){
     8ce:	39 5d b4             	cmp    %ebx,-0x4c(%ebp)
     8d1:	0f 85 d9 fe ff ff    	jne    7b0 <run_opt+0x70>
  if(trace)
     8d7:	8b 4d 08             	mov    0x8(%ebp),%ecx
     8da:	85 c9                	test   %ecx,%ecx
     8dc:	75 5e                	jne    93c <run_opt+0x1fc>
  *hits_out = hits;
     8de:	8b 45 0c             	mov    0xc(%ebp),%eax
     8e1:	8b 7d ac             	mov    -0x54(%ebp),%edi
     8e4:	89 38                	mov    %edi,(%eax)
}
     8e6:	8b 45 a0             	mov    -0x60(%ebp),%eax
     8e9:	8d 65 f4             	lea    -0xc(%ebp),%esp
     8ec:	5b                   	pop    %ebx
     8ed:	5e                   	pop    %esi
     8ee:	5f                   	pop    %edi
     8ef:	5d                   	pop    %ebp
     8f0:	c3                   	ret
     8f1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        printf(1, "ref %d: HIT   ", refs[i]);
     8f8:	83 ec 04             	sub    $0x4,%esp
     8fb:	50                   	push   %eax
     8fc:	68 11 11 00 00       	push   $0x1111
        printf(1, "ref %d: FAULT ", refs[i]);
     901:	6a 01                	push   $0x1
     903:	e8 98 04 00 00       	call   da0 <printf>
        print_frames(frames, nf);
     908:	89 f2                	mov    %esi,%edx
     90a:	89 f8                	mov    %edi,%eax
     90c:	e8 6f fa ff ff       	call   380 <print_frames>
        printf(1, "\n");
     911:	58                   	pop    %eax
     912:	5a                   	pop    %edx
     913:	68 94 11 00 00       	push   $0x1194
     918:	6a 01                	push   $0x1
     91a:	e8 81 04 00 00       	call   da0 <printf>
     91f:	83 c4 10             	add    $0x10,%esp
     922:	eb aa                	jmp    8ce <run_opt+0x18e>
    printf(1, "\n--- Optimal with %d frame(s) ---\n", nf);
     924:	83 ec 04             	sub    $0x4,%esp
     927:	56                   	push   %esi
     928:	68 e0 11 00 00       	push   $0x11e0
     92d:	6a 01                	push   $0x1
     92f:	e8 6c 04 00 00       	call   da0 <printf>
     934:	83 c4 10             	add    $0x10,%esp
     937:	e9 63 fe ff ff       	jmp    79f <run_opt+0x5f>
    printf(1, "Optimal: faults=%d hits=%d\n", faults, hits);
     93c:	ff 75 ac             	push   -0x54(%ebp)
     93f:	ff 75 a0             	push   -0x60(%ebp)
     942:	68 60 11 00 00       	push   $0x1160
     947:	6a 01                	push   $0x1
     949:	e8 52 04 00 00       	call   da0 <printf>
     94e:	83 c4 10             	add    $0x10,%esp
     951:	eb 8b                	jmp    8de <run_opt+0x19e>
     953:	8b 45 a4             	mov    -0x5c(%ebp),%eax
     956:	8b 5d 9c             	mov    -0x64(%ebp),%ebx
  return n + 1; // not referenced again: optimal victim
     959:	8b 4d b4             	mov    -0x4c(%ebp),%ecx
     95c:	83 c1 01             	add    $0x1,%ecx
     95f:	89 4d a8             	mov    %ecx,-0x58(%ebp)
     962:	e9 d2 fe ff ff       	jmp    839 <run_opt+0xf9>
     967:	90                   	nop
     968:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     96f:	00 
     970:	8d 42 01             	lea    0x1(%edx),%eax
     973:	e9 08 ff ff ff       	jmp    880 <run_opt+0x140>
        for(k = 1; k < nf; k++){
     978:	31 c9                	xor    %ecx,%ecx
     97a:	e9 29 ff ff ff       	jmp    8a8 <run_opt+0x168>
     97f:	90                   	nop

00000980 <strcpy>:
#include "user.h"
#include "x86.h"

char*
strcpy(char *s, const char *t)
{
     980:	55                   	push   %ebp
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
     981:	31 c0                	xor    %eax,%eax
{
     983:	89 e5                	mov    %esp,%ebp
     985:	53                   	push   %ebx
     986:	8b 4d 08             	mov    0x8(%ebp),%ecx
     989:	8b 5d 0c             	mov    0xc(%ebp),%ebx
     98c:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  while((*s++ = *t++) != 0)
     990:	0f b6 14 03          	movzbl (%ebx,%eax,1),%edx
     994:	88 14 01             	mov    %dl,(%ecx,%eax,1)
     997:	83 c0 01             	add    $0x1,%eax
     99a:	84 d2                	test   %dl,%dl
     99c:	75 f2                	jne    990 <strcpy+0x10>
    ;
  return os;
}
     99e:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     9a1:	89 c8                	mov    %ecx,%eax
     9a3:	c9                   	leave
     9a4:	c3                   	ret
     9a5:	8d 76 00             	lea    0x0(%esi),%esi
     9a8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     9af:	00 

000009b0 <strcmp>:

int
strcmp(const char *p, const char *q)
{
     9b0:	55                   	push   %ebp
     9b1:	89 e5                	mov    %esp,%ebp
     9b3:	53                   	push   %ebx
     9b4:	8b 55 08             	mov    0x8(%ebp),%edx
     9b7:	8b 4d 0c             	mov    0xc(%ebp),%ecx
  while(*p && *p == *q)
     9ba:	0f b6 02             	movzbl (%edx),%eax
     9bd:	84 c0                	test   %al,%al
     9bf:	75 2d                	jne    9ee <strcmp+0x3e>
     9c1:	eb 4a                	jmp    a0d <strcmp+0x5d>
     9c3:	eb 1b                	jmp    9e0 <strcmp+0x30>
     9c5:	8d 76 00             	lea    0x0(%esi),%esi
     9c8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     9cf:	00 
     9d0:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     9d7:	00 
     9d8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     9df:	00 
     9e0:	0f b6 42 01          	movzbl 0x1(%edx),%eax
    p++, q++;
     9e4:	83 c2 01             	add    $0x1,%edx
  while(*p && *p == *q)
     9e7:	84 c0                	test   %al,%al
     9e9:	74 15                	je     a00 <strcmp+0x50>
     9eb:	83 c1 01             	add    $0x1,%ecx
     9ee:	0f b6 19             	movzbl (%ecx),%ebx
     9f1:	38 c3                	cmp    %al,%bl
     9f3:	74 eb                	je     9e0 <strcmp+0x30>
  return (uchar)*p - (uchar)*q;
     9f5:	29 d8                	sub    %ebx,%eax
}
     9f7:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     9fa:	c9                   	leave
     9fb:	c3                   	ret
     9fc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
  return (uchar)*p - (uchar)*q;
     a00:	0f b6 59 01          	movzbl 0x1(%ecx),%ebx
     a04:	31 c0                	xor    %eax,%eax
     a06:	29 d8                	sub    %ebx,%eax
}
     a08:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     a0b:	c9                   	leave
     a0c:	c3                   	ret
  return (uchar)*p - (uchar)*q;
     a0d:	0f b6 19             	movzbl (%ecx),%ebx
     a10:	31 c0                	xor    %eax,%eax
     a12:	eb e1                	jmp    9f5 <strcmp+0x45>
     a14:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
     a18:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     a1f:	00 

00000a20 <strlen>:

uint
strlen(const char *s)
{
     a20:	55                   	push   %ebp
     a21:	89 e5                	mov    %esp,%ebp
     a23:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  for(n = 0; s[n]; n++)
     a26:	80 3a 00             	cmpb   $0x0,(%edx)
     a29:	74 15                	je     a40 <strlen+0x20>
     a2b:	31 c0                	xor    %eax,%eax
     a2d:	8d 76 00             	lea    0x0(%esi),%esi
     a30:	83 c0 01             	add    $0x1,%eax
     a33:	89 c1                	mov    %eax,%ecx
     a35:	80 3c 02 00          	cmpb   $0x0,(%edx,%eax,1)
     a39:	75 f5                	jne    a30 <strlen+0x10>
    ;
  return n;
}
     a3b:	89 c8                	mov    %ecx,%eax
     a3d:	5d                   	pop    %ebp
     a3e:	c3                   	ret
     a3f:	90                   	nop
  for(n = 0; s[n]; n++)
     a40:	31 c9                	xor    %ecx,%ecx
}
     a42:	5d                   	pop    %ebp
     a43:	89 c8                	mov    %ecx,%eax
     a45:	c3                   	ret
     a46:	66 90                	xchg   %ax,%ax
     a48:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     a4f:	00 

00000a50 <memset>:

void*
memset(void *dst, int c, uint n)
{
     a50:	55                   	push   %ebp
     a51:	89 e5                	mov    %esp,%ebp
     a53:	57                   	push   %edi
}

static inline void
stosb(void *addr, int data, int cnt)
{
  asm volatile("cld; rep stosb" :
     a54:	8b 4d 10             	mov    0x10(%ebp),%ecx
     a57:	8b 45 0c             	mov    0xc(%ebp),%eax
     a5a:	8b 7d 08             	mov    0x8(%ebp),%edi
     a5d:	fc                   	cld
     a5e:	f3 aa                	rep stos %al,%es:(%edi)
  stosb(dst, c, n);
  return dst;
}
     a60:	8b 45 08             	mov    0x8(%ebp),%eax
     a63:	8b 7d fc             	mov    -0x4(%ebp),%edi
     a66:	c9                   	leave
     a67:	c3                   	ret
     a68:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     a6f:	00 

00000a70 <strchr>:

char*
strchr(const char *s, char c)
{
     a70:	55                   	push   %ebp
     a71:	89 e5                	mov    %esp,%ebp
     a73:	8b 45 08             	mov    0x8(%ebp),%eax
     a76:	0f b6 4d 0c          	movzbl 0xc(%ebp),%ecx
  for(; *s; s++)
     a7a:	0f b6 10             	movzbl (%eax),%edx
     a7d:	84 d2                	test   %dl,%dl
     a7f:	75 1a                	jne    a9b <strchr+0x2b>
     a81:	eb 25                	jmp    aa8 <strchr+0x38>
     a83:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
     a88:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     a8f:	00 
     a90:	0f b6 50 01          	movzbl 0x1(%eax),%edx
     a94:	83 c0 01             	add    $0x1,%eax
     a97:	84 d2                	test   %dl,%dl
     a99:	74 0d                	je     aa8 <strchr+0x38>
    if(*s == c)
     a9b:	38 d1                	cmp    %dl,%cl
     a9d:	75 f1                	jne    a90 <strchr+0x20>
      return (char*)s;
  return 0;
}
     a9f:	5d                   	pop    %ebp
     aa0:	c3                   	ret
     aa1:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
  return 0;
     aa8:	31 c0                	xor    %eax,%eax
}
     aaa:	5d                   	pop    %ebp
     aab:	c3                   	ret
     aac:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000ab0 <gets>:

char*
gets(char *buf, int max)
{
     ab0:	55                   	push   %ebp
     ab1:	89 e5                	mov    %esp,%ebp
     ab3:	57                   	push   %edi
     ab4:	56                   	push   %esi
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    cc = read(0, &c, 1);
     ab5:	8d 7d e7             	lea    -0x19(%ebp),%edi
{
     ab8:	53                   	push   %ebx
  for(i=0; i+1 < max; ){
     ab9:	31 db                	xor    %ebx,%ebx
{
     abb:	83 ec 1c             	sub    $0x1c,%esp
  for(i=0; i+1 < max; ){
     abe:	eb 27                	jmp    ae7 <gets+0x37>
    cc = read(0, &c, 1);
     ac0:	83 ec 04             	sub    $0x4,%esp
     ac3:	6a 01                	push   $0x1
     ac5:	57                   	push   %edi
     ac6:	6a 00                	push   $0x0
     ac8:	e8 3e 01 00 00       	call   c0b <read>
    if(cc < 1)
     acd:	83 c4 10             	add    $0x10,%esp
     ad0:	85 c0                	test   %eax,%eax
     ad2:	7e 1d                	jle    af1 <gets+0x41>
      break;
    buf[i++] = c;
     ad4:	0f b6 45 e7          	movzbl -0x19(%ebp),%eax
     ad8:	8b 55 08             	mov    0x8(%ebp),%edx
     adb:	88 44 1a ff          	mov    %al,-0x1(%edx,%ebx,1)
    if(c == '\n' || c == '\r')
     adf:	3c 0a                	cmp    $0xa,%al
     ae1:	74 1d                	je     b00 <gets+0x50>
     ae3:	3c 0d                	cmp    $0xd,%al
     ae5:	74 19                	je     b00 <gets+0x50>
  for(i=0; i+1 < max; ){
     ae7:	89 de                	mov    %ebx,%esi
     ae9:	83 c3 01             	add    $0x1,%ebx
     aec:	3b 5d 0c             	cmp    0xc(%ebp),%ebx
     aef:	7c cf                	jl     ac0 <gets+0x10>
      break;
  }
  buf[i] = '\0';
     af1:	8b 45 08             	mov    0x8(%ebp),%eax
     af4:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
  return buf;
}
     af8:	8d 65 f4             	lea    -0xc(%ebp),%esp
     afb:	5b                   	pop    %ebx
     afc:	5e                   	pop    %esi
     afd:	5f                   	pop    %edi
     afe:	5d                   	pop    %ebp
     aff:	c3                   	ret
  buf[i] = '\0';
     b00:	8b 45 08             	mov    0x8(%ebp),%eax
    buf[i++] = c;
     b03:	89 de                	mov    %ebx,%esi
  buf[i] = '\0';
     b05:	c6 04 30 00          	movb   $0x0,(%eax,%esi,1)
}
     b09:	8d 65 f4             	lea    -0xc(%ebp),%esp
     b0c:	5b                   	pop    %ebx
     b0d:	5e                   	pop    %esi
     b0e:	5f                   	pop    %edi
     b0f:	5d                   	pop    %ebp
     b10:	c3                   	ret
     b11:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
     b18:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     b1f:	00 

00000b20 <stat>:

int
stat(const char *n, struct stat *st)
{
     b20:	55                   	push   %ebp
     b21:	89 e5                	mov    %esp,%ebp
     b23:	56                   	push   %esi
     b24:	53                   	push   %ebx
  int fd;
  int r;

  fd = open(n, O_RDONLY);
     b25:	83 ec 08             	sub    $0x8,%esp
     b28:	6a 00                	push   $0x0
     b2a:	ff 75 08             	push   0x8(%ebp)
     b2d:	e8 01 01 00 00       	call   c33 <open>
  if(fd < 0)
     b32:	83 c4 10             	add    $0x10,%esp
     b35:	85 c0                	test   %eax,%eax
     b37:	78 27                	js     b60 <stat+0x40>
    return -1;
  r = fstat(fd, st);
     b39:	83 ec 08             	sub    $0x8,%esp
     b3c:	ff 75 0c             	push   0xc(%ebp)
     b3f:	89 c3                	mov    %eax,%ebx
     b41:	50                   	push   %eax
     b42:	e8 04 01 00 00       	call   c4b <fstat>
  close(fd);
     b47:	89 1c 24             	mov    %ebx,(%esp)
  r = fstat(fd, st);
     b4a:	89 c6                	mov    %eax,%esi
  close(fd);
     b4c:	e8 ca 00 00 00       	call   c1b <close>
  return r;
     b51:	83 c4 10             	add    $0x10,%esp
}
     b54:	8d 65 f8             	lea    -0x8(%ebp),%esp
     b57:	89 f0                	mov    %esi,%eax
     b59:	5b                   	pop    %ebx
     b5a:	5e                   	pop    %esi
     b5b:	5d                   	pop    %ebp
     b5c:	c3                   	ret
     b5d:	8d 76 00             	lea    0x0(%esi),%esi
    return -1;
     b60:	be ff ff ff ff       	mov    $0xffffffff,%esi
     b65:	eb ed                	jmp    b54 <stat+0x34>
     b67:	90                   	nop
     b68:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     b6f:	00 

00000b70 <atoi>:

int
atoi(const char *s)
{
     b70:	55                   	push   %ebp
     b71:	89 e5                	mov    %esp,%ebp
     b73:	53                   	push   %ebx
     b74:	8b 55 08             	mov    0x8(%ebp),%edx
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
     b77:	0f be 02             	movsbl (%edx),%eax
     b7a:	8d 48 d0             	lea    -0x30(%eax),%ecx
     b7d:	80 f9 09             	cmp    $0x9,%cl
  n = 0;
     b80:	b9 00 00 00 00       	mov    $0x0,%ecx
  while('0' <= *s && *s <= '9')
     b85:	77 2e                	ja     bb5 <atoi+0x45>
     b87:	eb 17                	jmp    ba0 <atoi+0x30>
     b89:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
     b90:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     b97:	00 
     b98:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     b9f:	00 
    n = n*10 + *s++ - '0';
     ba0:	83 c2 01             	add    $0x1,%edx
     ba3:	8d 0c 89             	lea    (%ecx,%ecx,4),%ecx
     ba6:	8d 4c 48 d0          	lea    -0x30(%eax,%ecx,2),%ecx
  while('0' <= *s && *s <= '9')
     baa:	0f be 02             	movsbl (%edx),%eax
     bad:	8d 58 d0             	lea    -0x30(%eax),%ebx
     bb0:	80 fb 09             	cmp    $0x9,%bl
     bb3:	76 eb                	jbe    ba0 <atoi+0x30>
  return n;
}
     bb5:	8b 5d fc             	mov    -0x4(%ebp),%ebx
     bb8:	89 c8                	mov    %ecx,%eax
     bba:	c9                   	leave
     bbb:	c3                   	ret
     bbc:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi

00000bc0 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
     bc0:	55                   	push   %ebp
     bc1:	89 e5                	mov    %esp,%ebp
     bc3:	57                   	push   %edi
     bc4:	8b 45 10             	mov    0x10(%ebp),%eax
     bc7:	8b 55 08             	mov    0x8(%ebp),%edx
     bca:	56                   	push   %esi
     bcb:	8b 75 0c             	mov    0xc(%ebp),%esi
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  while(n-- > 0)
     bce:	85 c0                	test   %eax,%eax
     bd0:	7e 13                	jle    be5 <memmove+0x25>
     bd2:	01 d0                	add    %edx,%eax
  dst = vdst;
     bd4:	89 d7                	mov    %edx,%edi
     bd6:	66 90                	xchg   %ax,%ax
     bd8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     bdf:	00 
    *dst++ = *src++;
     be0:	a4                   	movsb  %ds:(%esi),%es:(%edi)
  while(n-- > 0)
     be1:	39 f8                	cmp    %edi,%eax
     be3:	75 fb                	jne    be0 <memmove+0x20>
  return vdst;
}
     be5:	5e                   	pop    %esi
     be6:	89 d0                	mov    %edx,%eax
     be8:	5f                   	pop    %edi
     be9:	5d                   	pop    %ebp
     bea:	c3                   	ret

00000beb <fork>:
  name: \
    movl $SYS_ ## name, %eax; \
    int $T_SYSCALL; \
    ret

SYSCALL(fork)
     beb:	b8 01 00 00 00       	mov    $0x1,%eax
     bf0:	cd 40                	int    $0x40
     bf2:	c3                   	ret

00000bf3 <exit>:
SYSCALL(exit)
     bf3:	b8 02 00 00 00       	mov    $0x2,%eax
     bf8:	cd 40                	int    $0x40
     bfa:	c3                   	ret

00000bfb <wait>:
SYSCALL(wait)
     bfb:	b8 03 00 00 00       	mov    $0x3,%eax
     c00:	cd 40                	int    $0x40
     c02:	c3                   	ret

00000c03 <pipe>:
SYSCALL(pipe)
     c03:	b8 04 00 00 00       	mov    $0x4,%eax
     c08:	cd 40                	int    $0x40
     c0a:	c3                   	ret

00000c0b <read>:
SYSCALL(read)
     c0b:	b8 05 00 00 00       	mov    $0x5,%eax
     c10:	cd 40                	int    $0x40
     c12:	c3                   	ret

00000c13 <write>:
SYSCALL(write)
     c13:	b8 10 00 00 00       	mov    $0x10,%eax
     c18:	cd 40                	int    $0x40
     c1a:	c3                   	ret

00000c1b <close>:
SYSCALL(close)
     c1b:	b8 15 00 00 00       	mov    $0x15,%eax
     c20:	cd 40                	int    $0x40
     c22:	c3                   	ret

00000c23 <kill>:
SYSCALL(kill)
     c23:	b8 06 00 00 00       	mov    $0x6,%eax
     c28:	cd 40                	int    $0x40
     c2a:	c3                   	ret

00000c2b <exec>:
SYSCALL(exec)
     c2b:	b8 07 00 00 00       	mov    $0x7,%eax
     c30:	cd 40                	int    $0x40
     c32:	c3                   	ret

00000c33 <open>:
SYSCALL(open)
     c33:	b8 0f 00 00 00       	mov    $0xf,%eax
     c38:	cd 40                	int    $0x40
     c3a:	c3                   	ret

00000c3b <mknod>:
SYSCALL(mknod)
     c3b:	b8 11 00 00 00       	mov    $0x11,%eax
     c40:	cd 40                	int    $0x40
     c42:	c3                   	ret

00000c43 <unlink>:
SYSCALL(unlink)
     c43:	b8 12 00 00 00       	mov    $0x12,%eax
     c48:	cd 40                	int    $0x40
     c4a:	c3                   	ret

00000c4b <fstat>:
SYSCALL(fstat)
     c4b:	b8 08 00 00 00       	mov    $0x8,%eax
     c50:	cd 40                	int    $0x40
     c52:	c3                   	ret

00000c53 <link>:
SYSCALL(link)
     c53:	b8 13 00 00 00       	mov    $0x13,%eax
     c58:	cd 40                	int    $0x40
     c5a:	c3                   	ret

00000c5b <mkdir>:
SYSCALL(mkdir)
     c5b:	b8 14 00 00 00       	mov    $0x14,%eax
     c60:	cd 40                	int    $0x40
     c62:	c3                   	ret

00000c63 <chdir>:
SYSCALL(chdir)
     c63:	b8 09 00 00 00       	mov    $0x9,%eax
     c68:	cd 40                	int    $0x40
     c6a:	c3                   	ret

00000c6b <dup>:
SYSCALL(dup)
     c6b:	b8 0a 00 00 00       	mov    $0xa,%eax
     c70:	cd 40                	int    $0x40
     c72:	c3                   	ret

00000c73 <getpid>:
SYSCALL(getpid)
     c73:	b8 0b 00 00 00       	mov    $0xb,%eax
     c78:	cd 40                	int    $0x40
     c7a:	c3                   	ret

00000c7b <sbrk>:
SYSCALL(sbrk)
     c7b:	b8 0c 00 00 00       	mov    $0xc,%eax
     c80:	cd 40                	int    $0x40
     c82:	c3                   	ret

00000c83 <sleep>:
SYSCALL(sleep)
     c83:	b8 0d 00 00 00       	mov    $0xd,%eax
     c88:	cd 40                	int    $0x40
     c8a:	c3                   	ret

00000c8b <uptime>:
SYSCALL(uptime)
     c8b:	b8 0e 00 00 00       	mov    $0xe,%eax
     c90:	cd 40                	int    $0x40
     c92:	c3                   	ret

00000c93 <vmprint>:

// Assignment 9 system calls
SYSCALL(vmprint)
     c93:	b8 16 00 00 00       	mov    $0x16,%eax
     c98:	cd 40                	int    $0x40
     c9a:	c3                   	ret

00000c9b <getfaults>:
SYSCALL(getfaults)
     c9b:	b8 17 00 00 00       	mov    $0x17,%eax
     ca0:	cd 40                	int    $0x40
     ca2:	c3                   	ret

00000ca3 <memstats>:

// Assignment 10 system calls
SYSCALL(memstats)
     ca3:	b8 18 00 00 00       	mov    $0x18,%eax
     ca8:	cd 40                	int    $0x40
     caa:	c3                   	ret

00000cab <vtop>:
SYSCALL(vtop)
     cab:	b8 19 00 00 00       	mov    $0x19,%eax
     cb0:	cd 40                	int    $0x40
     cb2:	c3                   	ret

00000cb3 <pageinfo>:
SYSCALL(pageinfo)
     cb3:	b8 1a 00 00 00       	mov    $0x1a,%eax
     cb8:	cd 40                	int    $0x40
     cba:	c3                   	ret

00000cbb <setreadonly>:
SYSCALL(setreadonly)
     cbb:	b8 1b 00 00 00       	mov    $0x1b,%eax
     cc0:	cd 40                	int    $0x40
     cc2:	c3                   	ret
     cc3:	66 90                	xchg   %ax,%ax
     cc5:	66 90                	xchg   %ax,%ax
     cc7:	66 90                	xchg   %ax,%ax
     cc9:	66 90                	xchg   %ax,%ax
     ccb:	66 90                	xchg   %ax,%ax
     ccd:	66 90                	xchg   %ax,%ax
     ccf:	66 90                	xchg   %ax,%ax
     cd1:	66 90                	xchg   %ax,%ax
     cd3:	66 90                	xchg   %ax,%ax
     cd5:	66 90                	xchg   %ax,%ax
     cd7:	66 90                	xchg   %ax,%ax
     cd9:	66 90                	xchg   %ax,%ax
     cdb:	66 90                	xchg   %ax,%ax
     cdd:	66 90                	xchg   %ax,%ax
     cdf:	90                   	nop

00000ce0 <printint>:
  write(fd, &c, 1);
}

static void
printint(int fd, int xx, int base, int sgn)
{
     ce0:	55                   	push   %ebp
     ce1:	89 e5                	mov    %esp,%ebp
     ce3:	57                   	push   %edi
     ce4:	56                   	push   %esi
     ce5:	53                   	push   %ebx
     ce6:	89 cb                	mov    %ecx,%ebx
     ce8:	83 ec 3c             	sub    $0x3c,%esp
     ceb:	89 45 c4             	mov    %eax,-0x3c(%ebp)
  char buf[16];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
     cee:	85 d2                	test   %edx,%edx
     cf0:	0f 89 9a 00 00 00    	jns    d90 <printint+0xb0>
     cf6:	f6 45 08 01          	testb  $0x1,0x8(%ebp)
     cfa:	0f 84 90 00 00 00    	je     d90 <printint+0xb0>
    neg = 1;
    x = -xx;
     d00:	f7 da                	neg    %edx
    neg = 1;
     d02:	b8 01 00 00 00       	mov    $0x1,%eax
     d07:	89 45 c0             	mov    %eax,-0x40(%ebp)
     d0a:	89 d1                	mov    %edx,%ecx
  } else {
    x = xx;
  }

  i = 0;
     d0c:	31 f6                	xor    %esi,%esi
     d0e:	66 90                	xchg   %ax,%ax
     d10:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     d17:	00 
     d18:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     d1f:	00 
  do{
    buf[i++] = digits[x % base];
     d20:	89 c8                	mov    %ecx,%eax
     d22:	31 d2                	xor    %edx,%edx
     d24:	89 f7                	mov    %esi,%edi
     d26:	f7 f3                	div    %ebx
     d28:	8d 76 01             	lea    0x1(%esi),%esi
  }while((x /= base) != 0);
     d2b:	39 d9                	cmp    %ebx,%ecx
    buf[i++] = digits[x % base];
     d2d:	0f b6 92 d4 14 00 00 	movzbl 0x14d4(%edx),%edx
  }while((x /= base) != 0);
     d34:	89 c1                	mov    %eax,%ecx
    buf[i++] = digits[x % base];
     d36:	88 54 35 d7          	mov    %dl,-0x29(%ebp,%esi,1)
  }while((x /= base) != 0);
     d3a:	73 e4                	jae    d20 <printint+0x40>
  if(neg)
     d3c:	8b 45 c0             	mov    -0x40(%ebp),%eax
     d3f:	85 c0                	test   %eax,%eax
     d41:	74 07                	je     d4a <printint+0x6a>
    buf[i++] = '-';
     d43:	c6 44 35 d8 2d       	movb   $0x2d,-0x28(%ebp,%esi,1)
     d48:	89 f7                	mov    %esi,%edi

  while(--i >= 0)
     d4a:	8d 74 3d d8          	lea    -0x28(%ebp,%edi,1),%esi
     d4e:	8b 7d c4             	mov    -0x3c(%ebp),%edi
     d51:	8d 5d d7             	lea    -0x29(%ebp),%ebx
     d54:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
     d58:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     d5f:	00 
    putc(fd, buf[i]);
     d60:	0f b6 06             	movzbl (%esi),%eax
  write(fd, &c, 1);
     d63:	83 ec 04             	sub    $0x4,%esp
  while(--i >= 0)
     d66:	83 ee 01             	sub    $0x1,%esi
     d69:	88 45 d7             	mov    %al,-0x29(%ebp)
  write(fd, &c, 1);
     d6c:	8d 45 d7             	lea    -0x29(%ebp),%eax
     d6f:	6a 01                	push   $0x1
     d71:	50                   	push   %eax
     d72:	57                   	push   %edi
     d73:	e8 9b fe ff ff       	call   c13 <write>
  while(--i >= 0)
     d78:	83 c4 10             	add    $0x10,%esp
     d7b:	39 f3                	cmp    %esi,%ebx
     d7d:	75 e1                	jne    d60 <printint+0x80>
}
     d7f:	8d 65 f4             	lea    -0xc(%ebp),%esp
     d82:	5b                   	pop    %ebx
     d83:	5e                   	pop    %esi
     d84:	5f                   	pop    %edi
     d85:	5d                   	pop    %ebp
     d86:	c3                   	ret
     d87:	90                   	nop
     d88:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     d8f:	00 
  neg = 0;
     d90:	31 c0                	xor    %eax,%eax
     d92:	e9 70 ff ff ff       	jmp    d07 <printint+0x27>
     d97:	90                   	nop
     d98:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     d9f:	00 

00000da0 <printf>:

// Print to the given fd. Only understands %d, %x, %p, %s.
void
printf(int fd, const char *fmt, ...)
{
     da0:	55                   	push   %ebp
     da1:	89 e5                	mov    %esp,%ebp
     da3:	57                   	push   %edi
     da4:	56                   	push   %esi
     da5:	53                   	push   %ebx
     da6:	83 ec 2c             	sub    $0x2c,%esp
  int c, i, state;
  uint *ap;

  state = 0;
  ap = (uint*)(void*)&fmt + 1;
  for(i = 0; fmt[i]; i++){
     da9:	8b 5d 0c             	mov    0xc(%ebp),%ebx
{
     dac:	8b 75 08             	mov    0x8(%ebp),%esi
  for(i = 0; fmt[i]; i++){
     daf:	0f b6 13             	movzbl (%ebx),%edx
     db2:	83 c3 01             	add    $0x1,%ebx
     db5:	84 d2                	test   %dl,%dl
     db7:	0f 84 a0 00 00 00    	je     e5d <printf+0xbd>
     dbd:	8d 45 10             	lea    0x10(%ebp),%eax
     dc0:	89 45 d4             	mov    %eax,-0x2c(%ebp)
    c = fmt[i] & 0xff;
     dc3:	8b 7d d4             	mov    -0x2c(%ebp),%edi
     dc6:	0f b6 c2             	movzbl %dl,%eax
    if(state == 0){
     dc9:	eb 28                	jmp    df3 <printf+0x53>
     dcb:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
  write(fd, &c, 1);
     dd0:	83 ec 04             	sub    $0x4,%esp
     dd3:	8d 45 e7             	lea    -0x19(%ebp),%eax
     dd6:	88 55 e7             	mov    %dl,-0x19(%ebp)
  for(i = 0; fmt[i]; i++){
     dd9:	83 c3 01             	add    $0x1,%ebx
  write(fd, &c, 1);
     ddc:	6a 01                	push   $0x1
     dde:	50                   	push   %eax
     ddf:	56                   	push   %esi
     de0:	e8 2e fe ff ff       	call   c13 <write>
  for(i = 0; fmt[i]; i++){
     de5:	0f b6 53 ff          	movzbl -0x1(%ebx),%edx
     de9:	83 c4 10             	add    $0x10,%esp
     dec:	84 d2                	test   %dl,%dl
     dee:	74 6d                	je     e5d <printf+0xbd>
    c = fmt[i] & 0xff;
     df0:	0f b6 c2             	movzbl %dl,%eax
      if(c == '%'){
     df3:	83 f8 25             	cmp    $0x25,%eax
     df6:	75 d8                	jne    dd0 <printf+0x30>
  for(i = 0; fmt[i]; i++){
     df8:	0f b6 13             	movzbl (%ebx),%edx
     dfb:	84 d2                	test   %dl,%dl
     dfd:	74 5e                	je     e5d <printf+0xbd>
    c = fmt[i] & 0xff;
     dff:	0f b6 c2             	movzbl %dl,%eax
        state = '%';
      } else {
        putc(fd, c);
      }
    } else if(state == '%'){
      if(c == 'd'){
     e02:	80 fa 25             	cmp    $0x25,%dl
     e05:	0f 84 25 01 00 00    	je     f30 <printf+0x190>
     e0b:	83 e8 63             	sub    $0x63,%eax
     e0e:	83 f8 15             	cmp    $0x15,%eax
     e11:	77 0d                	ja     e20 <printf+0x80>
     e13:	ff 24 85 7c 14 00 00 	jmp    *0x147c(,%eax,4)
     e1a:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
  write(fd, &c, 1);
     e20:	83 ec 04             	sub    $0x4,%esp
     e23:	8d 4d e7             	lea    -0x19(%ebp),%ecx
     e26:	88 55 d0             	mov    %dl,-0x30(%ebp)
        ap++;
      } else if(c == '%'){
        putc(fd, c);
      } else {
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
     e29:	c6 45 e7 25          	movb   $0x25,-0x19(%ebp)
  write(fd, &c, 1);
     e2d:	6a 01                	push   $0x1
     e2f:	51                   	push   %ecx
     e30:	89 4d d4             	mov    %ecx,-0x2c(%ebp)
     e33:	56                   	push   %esi
     e34:	e8 da fd ff ff       	call   c13 <write>
        putc(fd, c);
     e39:	0f b6 55 d0          	movzbl -0x30(%ebp),%edx
  write(fd, &c, 1);
     e3d:	83 c4 0c             	add    $0xc,%esp
     e40:	88 55 e7             	mov    %dl,-0x19(%ebp)
     e43:	6a 01                	push   $0x1
     e45:	8b 4d d4             	mov    -0x2c(%ebp),%ecx
     e48:	51                   	push   %ecx
  for(i = 0; fmt[i]; i++){
     e49:	83 c3 02             	add    $0x2,%ebx
  write(fd, &c, 1);
     e4c:	56                   	push   %esi
     e4d:	e8 c1 fd ff ff       	call   c13 <write>
  for(i = 0; fmt[i]; i++){
     e52:	0f b6 53 ff          	movzbl -0x1(%ebx),%edx
     e56:	83 c4 10             	add    $0x10,%esp
     e59:	84 d2                	test   %dl,%dl
     e5b:	75 93                	jne    df0 <printf+0x50>
      }
      state = 0;
    }
  }
}
     e5d:	8d 65 f4             	lea    -0xc(%ebp),%esp
     e60:	5b                   	pop    %ebx
     e61:	5e                   	pop    %esi
     e62:	5f                   	pop    %edi
     e63:	5d                   	pop    %ebp
     e64:	c3                   	ret
     e65:	8d 76 00             	lea    0x0(%esi),%esi
        printint(fd, *ap, 16, 0);
     e68:	83 ec 0c             	sub    $0xc,%esp
     e6b:	8b 17                	mov    (%edi),%edx
     e6d:	b9 10 00 00 00       	mov    $0x10,%ecx
     e72:	89 f0                	mov    %esi,%eax
     e74:	6a 00                	push   $0x0
     e76:	e8 65 fe ff ff       	call   ce0 <printint>
  for(i = 0; fmt[i]; i++){
     e7b:	0f b6 53 01          	movzbl 0x1(%ebx),%edx
     e7f:	83 c3 02             	add    $0x2,%ebx
     e82:	83 c4 10             	add    $0x10,%esp
     e85:	84 d2                	test   %dl,%dl
     e87:	74 d4                	je     e5d <printf+0xbd>
        ap++;
     e89:	83 c7 04             	add    $0x4,%edi
     e8c:	e9 5f ff ff ff       	jmp    df0 <printf+0x50>
     e91:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
        s = (char*)*ap;
     e98:	8b 07                	mov    (%edi),%eax
        ap++;
     e9a:	83 c7 04             	add    $0x4,%edi
        if(s == 0)
     e9d:	85 c0                	test   %eax,%eax
     e9f:	0f 84 9b 00 00 00    	je     f40 <printf+0x1a0>
        while(*s != 0){
     ea5:	0f b6 10             	movzbl (%eax),%edx
     ea8:	84 d2                	test   %dl,%dl
     eaa:	0f 84 a2 00 00 00    	je     f52 <printf+0x1b2>
     eb0:	89 7d d4             	mov    %edi,-0x2c(%ebp)
     eb3:	89 c7                	mov    %eax,%edi
     eb5:	89 d0                	mov    %edx,%eax
     eb7:	89 5d d0             	mov    %ebx,-0x30(%ebp)
     eba:	89 fb                	mov    %edi,%ebx
     ebc:	8d 7d e7             	lea    -0x19(%ebp),%edi
     ebf:	90                   	nop
  write(fd, &c, 1);
     ec0:	83 ec 04             	sub    $0x4,%esp
     ec3:	88 45 e7             	mov    %al,-0x19(%ebp)
          s++;
     ec6:	83 c3 01             	add    $0x1,%ebx
  write(fd, &c, 1);
     ec9:	6a 01                	push   $0x1
     ecb:	57                   	push   %edi
     ecc:	56                   	push   %esi
     ecd:	e8 41 fd ff ff       	call   c13 <write>
        while(*s != 0){
     ed2:	0f b6 03             	movzbl (%ebx),%eax
     ed5:	83 c4 10             	add    $0x10,%esp
     ed8:	84 c0                	test   %al,%al
     eda:	75 e4                	jne    ec0 <printf+0x120>
     edc:	8b 5d d0             	mov    -0x30(%ebp),%ebx
  for(i = 0; fmt[i]; i++){
     edf:	0f b6 53 01          	movzbl 0x1(%ebx),%edx
     ee3:	83 c3 02             	add    $0x2,%ebx
     ee6:	84 d2                	test   %dl,%dl
     ee8:	0f 85 d5 fe ff ff    	jne    dc3 <printf+0x23>
     eee:	e9 6a ff ff ff       	jmp    e5d <printf+0xbd>
     ef3:	2e 8d 74 26 00       	lea    %cs:0x0(%esi,%eiz,1),%esi
        printint(fd, *ap, 10, 1);
     ef8:	83 ec 0c             	sub    $0xc,%esp
     efb:	8b 17                	mov    (%edi),%edx
     efd:	b9 0a 00 00 00       	mov    $0xa,%ecx
     f02:	89 f0                	mov    %esi,%eax
     f04:	6a 01                	push   $0x1
     f06:	e8 d5 fd ff ff       	call   ce0 <printint>
  for(i = 0; fmt[i]; i++){
     f0b:	e9 6b ff ff ff       	jmp    e7b <printf+0xdb>
        putc(fd, *ap);
     f10:	8b 07                	mov    (%edi),%eax
  write(fd, &c, 1);
     f12:	83 ec 04             	sub    $0x4,%esp
     f15:	8d 4d e7             	lea    -0x19(%ebp),%ecx
        putc(fd, *ap);
     f18:	88 45 e7             	mov    %al,-0x19(%ebp)
  write(fd, &c, 1);
     f1b:	6a 01                	push   $0x1
     f1d:	51                   	push   %ecx
     f1e:	56                   	push   %esi
     f1f:	e8 ef fc ff ff       	call   c13 <write>
     f24:	e9 52 ff ff ff       	jmp    e7b <printf+0xdb>
     f29:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
     f30:	83 ec 04             	sub    $0x4,%esp
     f33:	88 55 e7             	mov    %dl,-0x19(%ebp)
     f36:	8d 4d e7             	lea    -0x19(%ebp),%ecx
     f39:	6a 01                	push   $0x1
     f3b:	e9 08 ff ff ff       	jmp    e48 <printf+0xa8>
          s = "(null)";
     f40:	89 7d d4             	mov    %edi,-0x2c(%ebp)
     f43:	b8 28 00 00 00       	mov    $0x28,%eax
     f48:	bf 96 11 00 00       	mov    $0x1196,%edi
     f4d:	e9 65 ff ff ff       	jmp    eb7 <printf+0x117>
  for(i = 0; fmt[i]; i++){
     f52:	0f b6 53 01          	movzbl 0x1(%ebx),%edx
     f56:	83 c3 02             	add    $0x2,%ebx
     f59:	84 d2                	test   %dl,%dl
     f5b:	0f 85 8f fe ff ff    	jne    df0 <printf+0x50>
     f61:	e9 f7 fe ff ff       	jmp    e5d <printf+0xbd>
     f66:	66 90                	xchg   %ax,%ax
     f68:	66 90                	xchg   %ax,%ax
     f6a:	66 90                	xchg   %ax,%ax
     f6c:	66 90                	xchg   %ax,%ax
     f6e:	66 90                	xchg   %ax,%ax
     f70:	66 90                	xchg   %ax,%ax
     f72:	66 90                	xchg   %ax,%ax
     f74:	66 90                	xchg   %ax,%ax
     f76:	66 90                	xchg   %ax,%ax
     f78:	66 90                	xchg   %ax,%ax
     f7a:	66 90                	xchg   %ax,%ax
     f7c:	66 90                	xchg   %ax,%ax
     f7e:	66 90                	xchg   %ax,%ax

00000f80 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
     f80:	55                   	push   %ebp
  Header *bp, *p;

  bp = (Header*)ap - 1;
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
     f81:	a1 50 18 00 00       	mov    0x1850,%eax
{
     f86:	89 e5                	mov    %esp,%ebp
     f88:	57                   	push   %edi
     f89:	56                   	push   %esi
     f8a:	53                   	push   %ebx
     f8b:	8b 5d 08             	mov    0x8(%ebp),%ebx
  bp = (Header*)ap - 1;
     f8e:	8d 4b f8             	lea    -0x8(%ebx),%ecx
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
     f91:	8d b4 26 00 00 00 00 	lea    0x0(%esi,%eiz,1),%esi
     f98:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
     f9f:	00 
     fa0:	89 c2                	mov    %eax,%edx
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
     fa2:	8b 00                	mov    (%eax),%eax
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
     fa4:	39 ca                	cmp    %ecx,%edx
     fa6:	73 30                	jae    fd8 <free+0x58>
     fa8:	39 c1                	cmp    %eax,%ecx
     faa:	72 04                	jb     fb0 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
     fac:	39 c2                	cmp    %eax,%edx
     fae:	72 f0                	jb     fa0 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
     fb0:	8b 73 fc             	mov    -0x4(%ebx),%esi
     fb3:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
     fb6:	39 f8                	cmp    %edi,%eax
     fb8:	74 36                	je     ff0 <free+0x70>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
     fba:	89 43 f8             	mov    %eax,-0x8(%ebx)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
     fbd:	8b 42 04             	mov    0x4(%edx),%eax
     fc0:	8d 34 c2             	lea    (%edx,%eax,8),%esi
     fc3:	39 f1                	cmp    %esi,%ecx
     fc5:	74 40                	je     1007 <free+0x87>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
     fc7:	89 0a                	mov    %ecx,(%edx)
  } else
    p->s.ptr = bp;
  freep = p;
}
     fc9:	5b                   	pop    %ebx
  freep = p;
     fca:	89 15 50 18 00 00    	mov    %edx,0x1850
}
     fd0:	5e                   	pop    %esi
     fd1:	5f                   	pop    %edi
     fd2:	5d                   	pop    %ebp
     fd3:	c3                   	ret
     fd4:	8d 74 26 00          	lea    0x0(%esi,%eiz,1),%esi
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
     fd8:	39 c2                	cmp    %eax,%edx
     fda:	72 c4                	jb     fa0 <free+0x20>
     fdc:	39 c1                	cmp    %eax,%ecx
     fde:	73 c0                	jae    fa0 <free+0x20>
  if(bp + bp->s.size == p->s.ptr){
     fe0:	8b 73 fc             	mov    -0x4(%ebx),%esi
     fe3:	8d 3c f1             	lea    (%ecx,%esi,8),%edi
     fe6:	39 f8                	cmp    %edi,%eax
     fe8:	75 d0                	jne    fba <free+0x3a>
     fea:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
    bp->s.size += p->s.ptr->s.size;
     ff0:	03 70 04             	add    0x4(%eax),%esi
     ff3:	89 73 fc             	mov    %esi,-0x4(%ebx)
    bp->s.ptr = p->s.ptr->s.ptr;
     ff6:	8b 02                	mov    (%edx),%eax
     ff8:	8b 00                	mov    (%eax),%eax
     ffa:	89 43 f8             	mov    %eax,-0x8(%ebx)
  if(p + p->s.size == bp){
     ffd:	8b 42 04             	mov    0x4(%edx),%eax
    1000:	8d 34 c2             	lea    (%edx,%eax,8),%esi
    1003:	39 f1                	cmp    %esi,%ecx
    1005:	75 c0                	jne    fc7 <free+0x47>
    p->s.size += bp->s.size;
    1007:	03 43 fc             	add    -0x4(%ebx),%eax
  freep = p;
    100a:	89 15 50 18 00 00    	mov    %edx,0x1850
    p->s.size += bp->s.size;
    1010:	89 42 04             	mov    %eax,0x4(%edx)
    p->s.ptr = bp->s.ptr;
    1013:	8b 4b f8             	mov    -0x8(%ebx),%ecx
    1016:	89 0a                	mov    %ecx,(%edx)
}
    1018:	5b                   	pop    %ebx
    1019:	5e                   	pop    %esi
    101a:	5f                   	pop    %edi
    101b:	5d                   	pop    %ebp
    101c:	c3                   	ret
    101d:	8d 76 00             	lea    0x0(%esi),%esi

00001020 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    1020:	55                   	push   %ebp
    1021:	89 e5                	mov    %esp,%ebp
    1023:	57                   	push   %edi
    1024:	56                   	push   %esi
    1025:	53                   	push   %ebx
    1026:	83 ec 0c             	sub    $0xc,%esp
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    1029:	8b 45 08             	mov    0x8(%ebp),%eax
  if((prevp = freep) == 0){
    102c:	8b 15 50 18 00 00    	mov    0x1850,%edx
  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    1032:	8d 78 07             	lea    0x7(%eax),%edi
    1035:	c1 ef 03             	shr    $0x3,%edi
    1038:	83 c7 01             	add    $0x1,%edi
  if((prevp = freep) == 0){
    103b:	85 d2                	test   %edx,%edx
    103d:	0f 84 8d 00 00 00    	je     10d0 <malloc+0xb0>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    1043:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
    1045:	8b 48 04             	mov    0x4(%eax),%ecx
    1048:	39 f9                	cmp    %edi,%ecx
    104a:	73 64                	jae    10b0 <malloc+0x90>
  if(nu < 4096)
    104c:	bb 00 10 00 00       	mov    $0x1000,%ebx
    1051:	39 df                	cmp    %ebx,%edi
    1053:	0f 43 df             	cmovae %edi,%ebx
  p = sbrk(nu * sizeof(Header));
    1056:	8d 34 dd 00 00 00 00 	lea    0x0(,%ebx,8),%esi
    105d:	eb 0a                	jmp    1069 <malloc+0x49>
    105f:	90                   	nop
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    1060:	8b 02                	mov    (%edx),%eax
    if(p->s.size >= nunits){
    1062:	8b 48 04             	mov    0x4(%eax),%ecx
    1065:	39 f9                	cmp    %edi,%ecx
    1067:	73 47                	jae    10b0 <malloc+0x90>
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
    1069:	89 c2                	mov    %eax,%edx
    106b:	39 05 50 18 00 00    	cmp    %eax,0x1850
    1071:	75 ed                	jne    1060 <malloc+0x40>
  p = sbrk(nu * sizeof(Header));
    1073:	83 ec 0c             	sub    $0xc,%esp
    1076:	56                   	push   %esi
    1077:	e8 ff fb ff ff       	call   c7b <sbrk>
  if(p == (char*)-1)
    107c:	83 c4 10             	add    $0x10,%esp
    107f:	83 f8 ff             	cmp    $0xffffffff,%eax
    1082:	74 1c                	je     10a0 <malloc+0x80>
  hp->s.size = nu;
    1084:	89 58 04             	mov    %ebx,0x4(%eax)
  free((void*)(hp + 1));
    1087:	83 ec 0c             	sub    $0xc,%esp
    108a:	83 c0 08             	add    $0x8,%eax
    108d:	50                   	push   %eax
    108e:	e8 ed fe ff ff       	call   f80 <free>
  return freep;
    1093:	8b 15 50 18 00 00    	mov    0x1850,%edx
      if((p = morecore(nunits)) == 0)
    1099:	83 c4 10             	add    $0x10,%esp
    109c:	85 d2                	test   %edx,%edx
    109e:	75 c0                	jne    1060 <malloc+0x40>
        return 0;
  }
}
    10a0:	8d 65 f4             	lea    -0xc(%ebp),%esp
        return 0;
    10a3:	31 c0                	xor    %eax,%eax
}
    10a5:	5b                   	pop    %ebx
    10a6:	5e                   	pop    %esi
    10a7:	5f                   	pop    %edi
    10a8:	5d                   	pop    %ebp
    10a9:	c3                   	ret
    10aa:	8d b6 00 00 00 00    	lea    0x0(%esi),%esi
      if(p->s.size == nunits)
    10b0:	39 cf                	cmp    %ecx,%edi
    10b2:	74 4c                	je     1100 <malloc+0xe0>
        p->s.size -= nunits;
    10b4:	29 f9                	sub    %edi,%ecx
    10b6:	89 48 04             	mov    %ecx,0x4(%eax)
        p += p->s.size;
    10b9:	8d 04 c8             	lea    (%eax,%ecx,8),%eax
        p->s.size = nunits;
    10bc:	89 78 04             	mov    %edi,0x4(%eax)
      freep = prevp;
    10bf:	89 15 50 18 00 00    	mov    %edx,0x1850
}
    10c5:	8d 65 f4             	lea    -0xc(%ebp),%esp
      return (void*)(p + 1);
    10c8:	83 c0 08             	add    $0x8,%eax
}
    10cb:	5b                   	pop    %ebx
    10cc:	5e                   	pop    %esi
    10cd:	5f                   	pop    %edi
    10ce:	5d                   	pop    %ebp
    10cf:	c3                   	ret
    base.s.ptr = freep = prevp = &base;
    10d0:	c7 05 50 18 00 00 54 	movl   $0x1854,0x1850
    10d7:	18 00 00 
    base.s.size = 0;
    10da:	b8 54 18 00 00       	mov    $0x1854,%eax
    base.s.ptr = freep = prevp = &base;
    10df:	c7 05 54 18 00 00 54 	movl   $0x1854,0x1854
    10e6:	18 00 00 
    base.s.size = 0;
    10e9:	c7 05 58 18 00 00 00 	movl   $0x0,0x1858
    10f0:	00 00 00 
    if(p->s.size >= nunits){
    10f3:	e9 54 ff ff ff       	jmp    104c <malloc+0x2c>
    10f8:	2e 8d b4 26 00 00 00 	lea    %cs:0x0(%esi,%eiz,1),%esi
    10ff:	00 
        prevp->s.ptr = p->s.ptr;
    1100:	8b 08                	mov    (%eax),%ecx
    1102:	89 0a                	mov    %ecx,(%edx)
    1104:	eb b9                	jmp    10bf <malloc+0x9f>
