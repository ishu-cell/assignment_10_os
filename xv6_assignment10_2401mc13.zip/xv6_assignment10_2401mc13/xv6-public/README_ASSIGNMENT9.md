# OS Lab Assignment 9 — xv6 x86

This is a **self-contained classic xv6-public x86** source tree with Assignment 9 implemented. It is based on the upstream xv6-public source, not on a separately modified scheduler-assignment folder. That choice avoids carrying over unrelated `set_burst`, `ticks_used`, or `remaining_time` changes from the development directory.

## Included tasks

### Q1 — Page-table printer
- Adds system call `vmprint()` (system-call number 22).
- Prints present user pages below `KERNBASE`, with virtual address, physical frame, and P/W/U flags.
- Reports valid user-page count and user page-table-page count.
- Adds `pttest.c`. It prints the map before `sbrk(4*4096)`, reserves the space, touches one address in each of four pages, then prints again. Touching is necessary because Q2 changes `sbrk` to lazy allocation.

### Q2 — Lazy allocation
- Positive `sbrk()` grows the process's virtual size without immediately allocating physical pages.
- `T_PGFLT` calls the lazy allocator for valid, previously unmapped addresses below the process size. Newly allocated pages are zeroed and user-writable.
- A page fault outside the reserved address space, a protection fault on an already present mapping, or an allocation failure kills the offending user process.
- `copyuvm()` skips unmapped lazy pages; `deallocuvm()` safely skips missing page-table entries and absent PTEs.
- Adds `getfaults()` (system-call number 23), a per-process counter, and `faulttest.c`.

### Q3 — FIFO and LRU
- Adds `pagerepl.c`, which prompts for a frame count and a space-separated reference string.
- Prints every reference, current frame contents, and HIT/FAULT for FIFO and LRU.
- Prints a comparison table for 3, 4, and 5 frames, including faults, hits, and hit ratio.
- With the assignment reference string and 3 frames, the expected page-fault counts are FIFO=15 and LRU=12.

## Build and run

On Ubuntu with the classic xv6 x86 build dependencies installed:

```sh
make clean
make
make fs.img
make CPUS=1 qemu-nox
```

At the xv6 shell:

```text
$ pttest
$ faulttest
$ pagerepl
```

For `pagerepl`, use the required reference string:

```text
7 0 1 2 0 3 0 4 2 3 0 3 2 1 2 0 1 7 0 1
```

Enter `3` for the trace frame count to verify the required 15 FIFO / 12 LRU results. The program then prints its 3/4/5-frame comparison table.

## Verification status

The kernel and filesystem/user programs compile successfully in the packaging environment using `make` and `make fs.img`. That environment does not have QEMU installed, so end-to-end runtime tests and real terminal screenshots have **not** been fabricated or claimed. Run the three commands in QEMU on your machine and capture actual screenshots for the submission.

## System-call numbers

The clean base uses 1–21 for the original xv6 calls. Assignment 9 adds `SYS_vmprint=22` and `SYS_getfaults=23` consistently in `syscall.h`, `syscall.c`, `sysproc.c`, `user.h`, and `usys.S`.
