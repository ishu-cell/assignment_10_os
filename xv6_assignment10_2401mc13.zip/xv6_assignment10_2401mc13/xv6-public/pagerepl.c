#include "types.h"
#include "user.h"

#define MAXREF 100
#define MAXFRAMES 10
#define INPUTSZ 256

static int
parse_refs(char *s, int refs[])
{
  int i = 0, n = 0, value;

  while(s[i] != 0 && n < MAXREF){
    while(s[i] == ' ' || s[i] == '\t' || s[i] == '\r' || s[i] == '\n')
      i++;
    if(s[i] == 0)
      break;
    if(s[i] < '0' || s[i] > '9'){
      i++;
      continue;
    }
    value = 0;
    while(s[i] >= '0' && s[i] <= '9'){
      value = value * 10 + (s[i] - '0');
      i++;
    }
    refs[n++] = value;
  }
  return n;
}

static int
fifo(int refs[], int n, int nf, int trace)
{
  int fr[MAXFRAMES];
  int i, j, hit, next = 0, faults = 0;

  for(i = 0; i < nf; i++)
    fr[i] = -1;

  if(trace)
    printf(1, "\nFIFO trace (%d frames)\n", nf);
  for(i = 0; i < n; i++){
    hit = 0;
    for(j = 0; j < nf; j++)
      if(fr[j] == refs[i]){ hit = 1; break; }
    if(!hit){
      faults++;
      fr[next] = refs[i];
      next = (next + 1) % nf;
    }
    if(trace){
      printf(1, "%d : [", refs[i]);
      for(j = 0; j < nf; j++)
        printf(1, "%s%d", j ? " " : "", fr[j]);
      printf(1, "] %s\n", hit ? "HIT" : "FAULT");
    }
  }
  return faults;
}

static int
lru(int refs[], int n, int nf, int trace)
{
  int fr[MAXFRAMES], last[MAXFRAMES];
  int i, j, hit, slot, oldest, faults = 0;

  for(i = 0; i < nf; i++){
    fr[i] = -1;
    last[i] = -1;
  }

  if(trace)
    printf(1, "\nLRU trace (%d frames)\n", nf);
  for(i = 0; i < n; i++){
    hit = 0;
    slot = -1;
    for(j = 0; j < nf; j++){
      if(fr[j] == refs[i]){
        hit = 1;
        slot = j;
        break;
      }
    }
    if(hit){
      last[slot] = i;
    } else {
      faults++;
      slot = -1;
      for(j = 0; j < nf; j++)
        if(fr[j] == -1){ slot = j; break; }
      if(slot == -1){
        slot = 0;
        oldest = last[0];
        for(j = 1; j < nf; j++)
          if(last[j] < oldest){ oldest = last[j]; slot = j; }
      }
      fr[slot] = refs[i];
      last[slot] = i;
    }
    if(trace){
      printf(1, "%d : [", refs[i]);
      for(j = 0; j < nf; j++)
        printf(1, "%s%d", j ? " " : "", fr[j]);
      printf(1, "] %s\n", hit ? "HIT" : "FAULT");
    }
  }
  return faults;
}

int
main(void)
{
  char line[INPUTSZ];
  int refs[MAXREF];
  int n, nf, ff, fl, f, faults, hits;

  printf(1, "Page replacement: FIFO and LRU\n");
  printf(1, "Enter frame count for detailed trace (1-%d): ", MAXFRAMES);
  if(gets(line, sizeof(line)) == 0){
    printf(1, "Input error\n");
    exit();
  }
  nf = atoi(line);
  if(nf < 1 || nf > MAXFRAMES){
    printf(1, "Invalid frame count\n");
    exit();
  }

  printf(1, "Enter space-separated reference string (up to %d pages):\n", MAXREF);
  if(gets(line, sizeof(line)) == 0){
    printf(1, "Input error\n");
    exit();
  }
  n = parse_refs(line, refs);
  if(n <= 0){
    printf(1, "No references were entered\n");
    exit();
  }

  ff = fifo(refs, n, nf, 1);
  fl = lru(refs, n, nf, 1);
  printf(1, "\nSummary for %d frames and %d references\n", nf, n);
  printf(1, "FIFO: faults=%d hits=%d hit ratio=%d%%\n", ff, n-ff, ((n-ff)*100)/n);
  printf(1, "LRU : faults=%d hits=%d hit ratio=%d%%\n", fl, n-fl, ((n-fl)*100)/n);

  printf(1, "\nComparison table (same reference string)\n");
  printf(1, "Frames  Algorithm  Faults  Hits  HitRatio(%%)\n");
  for(f = 3; f <= 5; f++){
    faults = fifo(refs, n, f, 0);
    hits = n - faults;
    printf(1, "%d\tFIFO\t%d\t%d\t%d%%\n", f, faults, hits, (hits*100)/n);
    faults = lru(refs, n, f, 0);
    hits = n - faults;
    printf(1, "%d\tLRU\t%d\t%d\t%d%%\n", f, faults, hits, (hits*100)/n);
  }
  exit();
}
