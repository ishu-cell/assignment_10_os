#include "types.h"
#include "user.h"

#define PGSIZE 4096

int
main(void)
{
  volatile char *mem;
  int pa0, pa1, bad;
  int va;

  printf(1, "Assignment 10 - Q2: virtual-to-physical translation\n");

  mem = (volatile char*)sbrk(2 * PGSIZE);
  if(mem == (char*)-1){
    printf(1, "vttest: sbrk failed\n");
    exit();
  }

  // Force both lazy pages to be mapped before asking for translations.
  mem[0] = 'A';
  mem[PGSIZE] = 'B';

  va = (int)mem;
  pa0 = vtop(va);
  pa1 = vtop(va + 123);
  printf(1, "VA 0x%x -> PA 0x%x\n", va, pa0);
  printf(1, "VA 0x%x -> PA 0x%x\n", va + 123, pa1);

  // This address is below KERNBASE but is not mapped by this process.
  bad = vtop(0x7ffff000);
  printf(1, "Invalid/unmapped VA 0x7ffff000 -> %d (expected -1)\n", bad);

  exit();
}
