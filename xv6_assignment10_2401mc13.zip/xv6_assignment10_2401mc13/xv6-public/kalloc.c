// Physical memory allocator, intended to allocate
// memory for user processes, kernel stacks, page table pages,
// and pipe buffers. Allocates 4096-byte pages.

#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"

void freerange(void *vstart, void *vend);
extern char end[]; // first address after kernel loaded from ELF file
                   // defined by the kernel linker script in kernel.ld

struct run {
  struct run *next;
};

struct {
  struct spinlock lock;
  int use_lock;
  struct run *freelist;
  // Assignment 10: allocator counters. They start tracking after kinit2
  // enables locking, so bootstrap free-list construction is not counted.
  uint total_allocated;
  uint total_freed;
} kmem;

// Initialization happens in two phases.
// 1. main() calls kinit1() while still using entrypgdir to place just
// the pages mapped by entrypgdir on free list.
// 2. main() calls kinit2() with the rest of the physical pages
// after installing a full page table that maps them on all cores.
void
kinit1(void *vstart, void *vend)
{
  initlock(&kmem.lock, "kmem");
  kmem.use_lock = 0;
  freerange(vstart, vend);
}

void
kinit2(void *vstart, void *vend)
{
  freerange(vstart, vend);
  kmem.use_lock = 1;
}

void
freerange(void *vstart, void *vend)
{
  char *p;
  p = (char*)PGROUNDUP((uint)vstart);
  for(; p + PGSIZE <= (char*)vend; p += PGSIZE)
    kfree(p);
}
//PAGEBREAK: 21
// Free the page of physical memory pointed at by v,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void
kfree(char *v)
{
  struct run *r;

  if((uint)v % PGSIZE || v < end || V2P(v) >= PHYSTOP)
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(v, 1, PGSIZE);

  if(kmem.use_lock)
    acquire(&kmem.lock);
  r = (struct run*)v;
  r->next = kmem.freelist;
  kmem.freelist = r;
  if(kmem.use_lock){
    // Count only runtime frees, not the initial freerange() setup.
    kmem.total_freed++;
    release(&kmem.lock);
  }
}

// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
char*
kalloc(void)
{
  struct run *r;

  if(kmem.use_lock)
    acquire(&kmem.lock);
  r = kmem.freelist;
  if(r){
    kmem.freelist = r->next;
    if(kmem.use_lock)
      kmem.total_allocated++;
  }
  if(kmem.use_lock)
    release(&kmem.lock);
  return (char*)r;
}

// Assignment 10: print global physical-page allocator statistics.
// Counters cover allocations/frees after the allocator enters its locked
// runtime phase; the available count is the current free-list length.
void
printmemstats(void)
{
  struct run *r;
  uint allocated, freed, available;
  int current;

  acquire(&kmem.lock);
  allocated = kmem.total_allocated;
  freed = kmem.total_freed;
  available = 0;
  for(r = kmem.freelist; r; r = r->next)
    available++;
  release(&kmem.lock);

  current = (int)allocated - (int)freed;
  cprintf("Physical memory statistics (pages):\n");
  cprintf("  Total allocated pages : %d\n", (int)allocated);
  cprintf("  Total freed pages     : %d\n", (int)freed);
  cprintf("  Currently allocated  : %d\n", current);
  cprintf("  Available free pages  : %d\n", (int)available);
}


