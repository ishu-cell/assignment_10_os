#include "types.h"
#include "user.h"

#define PGSIZE 4096
#define NPAGES 32

int
main(void)
{
  char *base;
  uint start;
  int i, pid;

  base = sbrk(NPAGES * PGSIZE);
  if(base == (char*)-1){
    printf(1, "faulttest: sbrk failed\n");
    exit();
  }

  // Align within the reserved range and touch five distinct lazy pages.
  start = ((uint)base + PGSIZE - 1) & ~(PGSIZE - 1);
  for(i = 0; i < 5; i++)
    *((char*)(start + i * PGSIZE)) = (char)('A' + i);

  printf(1, "Faults after five distinct first accesses: %d (expected 5)\n",
         getfaults());

  // A fault beyond the process's reserved address space must kill only child.
  pid = fork();
  if(pid < 0){
    printf(1, "faulttest: fork failed\n");
    exit();
  }
  if(pid == 0){
    printf(1, "Child now accesses beyond its allocated size\n");
    base[NPAGES * PGSIZE] = 'X';
    printf(1, "ERROR: invalid access unexpectedly continued\n");
    exit();
  }
  wait();
  printf(1, "Parent survived the child's invalid access\n");
  exit();
}
