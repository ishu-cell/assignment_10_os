# Assignment 10 — Implementation Report

## Q1. Tracking physical memory allocation

The physical page allocator in `kalloc.c` was extended with two counters. `total_allocated` increments whenever `kalloc()` successfully removes a page from the free list, and `total_freed` increments whenever a runtime `kfree()` returns a page to the free list. Boot-time free-list initialization is excluded from the counters. The kernel routine `printmemstats()` safely reads the counters and traverses the free list while holding the allocator lock. It displays allocated, freed, currently allocated (`allocated - freed`), and available page counts. System call `memstats()` exposes this report to user programs. `memtest.c` reserves three pages using `sbrk()`, writes to one byte in each page to ensure physical backing exists in this lazy-allocation tree, prints the statistics, releases the range, and prints the statistics again.

## Q2. Virtual-to-physical address translation

The `vtop()` kernel routine uses `walkpgdir()` to locate the PTE for the current process. It rejects addresses at or above `KERNBASE`, missing page-table entries, non-present entries, and non-user mappings. For a valid page it combines the physical frame base from `PTE_ADDR(*pte)` with the original virtual address's page offset. System call `vtop()` returns the translated physical address or `-1`. `vttest.c` touches two allocated pages before translating them and checks an unmapped address, which should return `-1`.

## Q3. Page information and protection

`pageinfo()` checks that a virtual address refers to a present user page, then prints its physical frame number and the P, W, and U flags. `setreadonly()` clears `PTE_W` for the selected page and reloads CR3 so the processor does not continue using a stale writable TLB translation. `pagetest.c` first maps and inspects a page, makes it read-only, and inspects it again. A child then attempts a write; the existing page-fault handler terminates that child because the page is already mapped but is no longer writable. The parent waits and continues, showing that the protection fault is isolated to the child.

## Q4. Page replacement

`pagereplace.c` implements FIFO, LRU, and Optimal replacement. FIFO advances a circular replacement pointer on each fault. LRU records the most recent reference index for every occupied frame and replaces the least recently used page. Optimal looks ahead in the known reference string and replaces the resident page whose next use is farthest in the future (or which is never used again). For the required 20-reference string and 3 frames, the expected fault totals are FIFO 15, LRU 12, and Optimal 9. The program also calculates hits, hit ratio, and fault ratio for 3, 4, and 5 frames. Optimal performs best for this known reference string because it uses future knowledge; LRU ties it for 4 and 5 frames in this test.

## Verification

The kernel and filesystem image with all four user programs compile successfully. Runtime output and screenshots must be captured from the student's own QEMU run; expected values are supplied separately as a comparison reference, not as claimed screenshots.
